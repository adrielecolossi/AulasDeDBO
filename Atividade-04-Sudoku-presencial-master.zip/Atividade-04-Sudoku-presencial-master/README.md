# Atividade-04-presencial
Sudoku criado no mês de abril, em aula.
