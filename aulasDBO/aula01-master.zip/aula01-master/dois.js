console.log('dois.js');
console.log(x);