//o que é uma instrução?
// ORDEM
//SEGUNDO UMA LINGUAGEM/SINTAXE
// OS ; delimitam uma instrução
//exemplo:

console.log('imprima isto!');
console.log('mais isso'); console.log('e mais isto');

//podemos colocar na mesma linha desde que delimitemos com ;
//três instruções