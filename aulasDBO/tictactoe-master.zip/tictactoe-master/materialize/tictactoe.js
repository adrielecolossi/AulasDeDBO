console.log("TicTacToe!")

let matriz = [['', '', '', ''], ['', '', '', ''], ['', '', '', '']];
let td = document.body.children[4].querySelectorAll('td')


let usd = [];
for (let i = 0; i < td.length; i++) {
    let change = false;
    td[i].addEventListener('click', function (e) {
        let y = document.body.children[4].querySelectorAll('td')[i]; 
        if (document.body.children[4].querySelectorAll('td')[i].textContent === '') {
            usd.push(i);
            y.textContent = "X";
        } else{
            alert("Você não pode mexer aqui");
            M.toast({ html: 'Você não pode mexer aqui!' })
        }
       /* console.log(usd)
        if (usd.indexOf(i) === -1) {
            change = true;
        } else {
            change = false;
        }    
        
        if(change===true){
            y.textContent="X";
        } else{
            alert("Você não pode mexer aqui");
        }
        */
    })
}



