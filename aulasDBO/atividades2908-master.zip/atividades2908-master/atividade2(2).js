/*
1. Crie um array vazio de
filmes e trate-o como uma pilha. Faça:
a) Adicione 5 filmes na pilha;
b) Mostre os filmes que tenham mais que 20 caracteres;
c) Remova e mostre o último filme da pilha.
*/

//na letra c o que iremos remover é o primeiro livro pois em uma pilha ele é o 1 

let filmes=['','','','',''];

//a)

for(let k=0; k<5; k++){
    filmes[k]= prompt("Informe um filme para colocar na pilha");
}

console.log(filmes);

//b)

for (let k = 0; k < 5; k++) {
    if(filmes[k].length>20){
        alert("O " + k + " filme adicionado à pilha, " + filmes[k] + " possui mais de 20 caracteres" )
    } 
}

//c)

alert("O ultimo filme da pilha(que foi o primeiro a ser adicionado) é " +filmes[0])
newfilmes = ['', '', '', ''];
for(let k=1; k<5; k++){
    newfilmes[k]= filmes[k]
}

console.log(newfilmes);


/*

2. Crie
um array que represente uma fila vazia para entrada no cinema.
a) Adicione os seguintes clientes: Carlos, Maria, João, Marcos, Márcia e Beatriz.
b)
Mostre os clientes que iniciem com a letra M na tela;
c) Remova os dois próximos clientes e mostre na tela.

*/

let fila=[]

//a)

fila.push("Carlos")
fila.push("Maria")
fila.push("João")
fila.push("Marcos")
fila.push("Marcia")
fila.push("Beatriz")

console.log(fila);
//b)

let letram=[]
for(let x=0; x<6; x++){
    if(fila[x].indexOf('M')!==-1){
        letram.push(fila[x])
    }
}

alert("As pessoas da fila que o nome começa com M são: " + letram)

/*

3. Crie um array para armazenar objetos do tipo
estudante.
O estudante contém duas chaves: nome
e idade.
a) Adicione cinco estudantes no array, são eles: Maria 25 anos, Carlos 30 anos, Jussara 45 anos,
Joaquim 20 anos, Marcos 18 anos e Danilo 32 anos;
b) Insira o estudante Júnior 12 anos na terceira posição da lista;
c) Substitua a estudante Jussara 45 anos pela estudante Jurema 42 anos;
b) Conte quantos estudantes possuem idade maior que 30 anos e mostre na tela;
c) Mostre na tela a média de idade dos estudantes.
c) Remova os dois próximos clientes e mostre na tela.
*/

let estudantes= [];

estudante1= {
    nome: 'Maria',
    idade: 25
}


estudante2 = {
    nome: 'Carlos',
    idade: 30
}


estudante3 = {
    nome: 'Jussara',
    idade: 45
}


estudante4 = {
    nome: 'Joaquim',
    idade: 20
}


estudante5 = {
    nome: 'Marcos',
    idade: 18
}

estudante6 = {
    nome: 'Danilo',
    idade: 32
}

fila.push(estudante1);
fila.push(estudante2);
fila.push(estudante3);
fila.push(estudante4);
fila.push(estudante5);
fila.push(estudante6);

console.log(fila);
//b)
let fila2=[]
for(let k=0; k<6; k++){
fila2.push(fila[k])
}
fila2.push(junior={nome:'Junior', idade:12})
for (let k = 6; k < fila.length; k++) {
    fila2.push(fila[k])
}

console.log(fila2);

//c)

let fila3 = []
let Jurema = {
    nome:   'Jurema',
    idade: 42
}
for (let k = 0; k < fila.length; k++) {
    if(k==8){
        
        fila3[8]= Jurema;
    } else{
        fila3[k]=fila[k]
    }
}

console.log(fila3);

//d)

var maioresque30=[]
for(let f=5; f<fila.length; f++){
    if(fila[f].idade>30){
        maioresque30.push(fila[f].nome);
    }
}

alert("As pessoas que tem mais de 30 anos são " + maioresque30);

//e)

let soma=0;

for (let f = 6; f < fila.length; f++) {
   soma+= fila[f].idade;
}

media=soma/6;

alert("A media entre os estudantes que informaram sua idade é aproximadamente " + media.toFixed(0));

//f)

var fila4=fila;

fila.shift()
fila.shift()

console.log(fila4)