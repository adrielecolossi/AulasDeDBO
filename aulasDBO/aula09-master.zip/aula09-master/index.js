/*const a= document.querySelector('audio');

//undefined
a
//<audio controls>​…​</audio>​
a.currentTime
//0
a.currentTime= 60
//60
a.duration= 180.3
//180.3
a.play()
//Promise {<pending>}
a.pause()
//undefined
 a.src
//""
 a.src= 'avengers.mp3'
"avengers.mp3" */

console.log('index.js');
const bt1= document.querySelector('button')[0]; //o primeiro botão é assim
//const bt2= document.querySelector('button:last-of-type');
const bt2= document.querySelector('button')[1]; //o primeiro botão é assim
const audio= document.querySelector('audio');
bt1.addEventListener('click', function(){
     audio.src='highhopes.mp3';
     audio.play();
});

bt2.addEventListener('click', function(e){
    audio.src= 'avengers.mp3'
    audio.play()
})