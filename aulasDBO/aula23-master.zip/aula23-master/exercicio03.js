/*3
    .Escreva uma função construtora que defina a estrutura de um objeto
denominado
Pizza
    , o qual
deverá possuir as seguintes características:
a) Inicializar os atributos nome, preço e tamanho.O atributo ingredientes
deverá ser um array vazio.
    b) Elaborar um método no interior da função construtora para que possamos
adicionar ingredientes.
    c) Escreva outro método para que possamos excluir um ing
rediente da pizza.
    c) Também deverá ter um método que retorne os ingredientes da pizza na
forma de uma string.
2. Na sequência, crie um array vazio para armazenar pizzas e faça:
a) Adicione cinco pizzas no array.
    b) Mostre na tela o nome, tamanho, preço e
ingredientes de cada pizza.
    c) Exclua o ingrediente tomate de todas as pizzas.
        d) Mostre na tela somente as pizzas que possuem ovo como ingrediente.
3. Realize as seguintes operações de ordenação, mostrando os resultados na
tela:
a) Ordene as pizzas por or
dem de nome de forma crescente.
    b) Ordene as pizzas por preço de forma decrescente.
        c) Ordene os ingredientes de cada pizza presente no array

*/


function Pizza() {
    this.nome = '';
    this.preço = 0;
    this.tamanho = '';
    this.ingredientes = [];
    this.addIngredientes = function () {
        let numdeingredientes = parseInt(prompt("Informe o numero de ingredientes"));
        for (let x = 0; x < numdeingredientes; x++) {
            this.ingredientes[x] = prompt("Informe o ingrediente numero " + (x + 1))
        }
    }
    this.excluirIngredientes = function () {

        let ex = parseInt(prompt("Informe o numero do ingrediente que você deseja excluir"));
        let numdeingredientes = parseInt(prompt("Informe o numero de ingredientes"));
        for (let x = 0; x < this.ingredientes.length; x++) {
            if (x === ex) {
                this.ingredientes[x - 1] = 'este ingrediente foi excluido por você';
            }
            if (x !== ex) {
                this.ingredientes[x] = this.ingredientes[x]
            }
        }
    }
    this.ingredientesstring = function () {
        let oalert = 'Os ingredientes são:'
        for (let x = 0; x < this.ingredientes.length; x++) {
            oalert += '\n ' + (x + 1) + " " + this.ingredientes[x];
        }
        alert(oalert);
    }
    this.excluirtomate = function () {
        for (let x = 0; x < this.ingredientes.length; x++) {
            if (this.ingredientes[x] !== "tomate" && this.ingredientes[x] !== "Tomate") {
                this.ingredientes[x] = this.ingredientes[x]
            } else {
                this.ingredientes[x] = '';
            }
        }
    }
    this.mostrarapenasovo = function () {
        if (this.ingredientes.indexOf('Ovo') !== -1 || this.ingredientes.indexOf('ovo') !== -1) {
            alert('A pizza ' + this.nome + ' possui ovos')
        }
    }
}

pizza1 = new Pizza;
pizza1.nome = prompt("Diga o nome da pizza");
console.log(pizza1.nome)
pizza1.preço = prompt("Informe o preço da pizza");
console.log(pizza1.preço)
pizza1.tamanho = prompt("Informe o tamanho da pizza");
console.log(pizza1.tamanho);
pizza1.addIngredientes(); //METODO RESPONSAVEL POR ADD INGREDIENTES
console.log(pizza1.ingredientes);
pizza1.excluirIngredientes(); //METODO RESPONSAVEL POR EXCLUIR INGREDIENTES
console.log(pizza1.ingredientes);
pizza1.ingredientesstring()


/*
2.
Na sequência, crie um array vazio para armazenar pizzas e faça:
a) Adicione cinco pizzas no array.
b)
Mostre na tela o nome, tamanho, preço e ingredientes de cada pizza.
c) Exclua o ingrediente tomate de todas as pizzas.
d) Mostre na tela somente as pizzas que possuem ovo como ingrediente.
*/

alert("Exercicio 2");
let pizzas = [];

var pizza2 = new Pizza;
pizza2.nome = prompt("Diga o nome da pizza 1 ");
pizza2.preço = prompt("Informe o preço da pizza 1 ");
pizza2.tamanho = prompt("Informe o tamanho da pizza 1 ");
pizza2.addIngredientes(); //METODO RESPONSAVEL POR ADD INGREDIENTES

var pizza3 = new Pizza;
pizza3.nome = prompt("Diga o nome da pizza 2 ");
pizza3.preço = prompt("Informe o preço da pizza 2 ");
pizza3.tamanho = prompt("Informe o tamanho da pizza 2 ");
pizza3.addIngredientes(); //METODO RESPONSAVEL POR ADD INGREDIENTES

var pizza4 = new Pizza;
pizza4.nome = prompt("Diga o nome da pizza 3 ");
pizza4.preço = prompt("Informe o preço da pizza 3 ");
pizza4.tamanho = prompt("Informe o tamanho da pizza 3 ");
pizza4.addIngredientes(); //METODO RESPONSAVEL POR ADD INGREDIENTES

var pizza5 = new Pizza;
pizza5.nome = prompt("Diga o nome da pizza 4 ");
pizza5.preço = prompt("Informe o preço da pizza 4 ");
pizza5.tamanho = prompt("Informe o tamanho da pizza 4 ");
pizza5.addIngredientes(); //METODO RESPONSAVEL POR ADD INGREDIENTES


var pizza6 = new Pizza;
pizza6.nome = prompt("Diga o nome da pizza 5 ");
pizza6.preço = prompt("Informe o preço da pizza 5 ");
pizza6.tamanho = prompt("Informe o tamanho da pizza 5 ");
pizza6.addIngredientes(); //METODO RESPONSAVEL POR ADD INGREDIENTES


alert("Pizza1\n" + "Nome: " + pizza2.nome + "\n" + "Preço: " + pizza2.preço + "\nTamanho: " + pizza2.tamanho + "\nIngredientes: " + pizza2.ingredientes);

alert("Pizza2\n" + "Nome: " + pizza3.nome + "\n" + "Preço: " + pizza3.preço + "\nTamanho: " + pizza3.tamanho + "\nIngredientes: " + pizza3.ingredientes);

alert("Pizza3\n" + "Nome: " + pizza4.nome + "\n" + "Preço: " + pizza4.preço + "\nTamanho: " + pizza4.tamanho + "\nIngredientes: " + pizza4.ingredientes);

alert("Pizza4\n" + "Nome: " + pizza5.nome + "\n" + "Preço: " + pizza5.preço + "\nTamanho: " + pizza5.tamanho + "\nIngredientes: " + pizza5.ingredientes);

alert("Pizza5\n" + "Nome: " + pizza6.nome + "\n" + "Preço: " + pizza6.preço + "\nTamanho: " + pizza6.tamanho + "\nIngredientes: " + pizza6.ingredientes);


pizzas[0] = pizza2;
pizzas[1] = pizza3;
pizzas[2] = pizza4;
pizzas[3] = pizza5;
pizzas[4] = pizza6;

//parte sobre excluir tomate de todas as pizzas

alert("Excluindo os tomates!");
pizza2.excluirtomate()
console.log("pizza2 " + pizza2.ingredientes)
pizza3.excluirtomate()
console.log("pizza2 " + pizza3.ingredientes)
pizza4.excluirtomate()
console.log("pizza2 " + pizza4.ingredientes)
pizza5.excluirtomate()
console.log("pizza2 " + pizza5.ingredientes)
pizza6.excluirtomate()
console.log("pizza2 " + pizza6.ingredientes)

//exibir apenas as que possuem ovo

pizza2.mostrarapenasovo();
pizza3.mostrarapenasovo();
pizza4.mostrarapenasovo();
pizza5.mostrarapenasovo();
pizza6.mostrarapenasovo();

alert("Exercicio 3 ")

//a) Ordene as pizzas por ordem de nome de forma crescente.

var ordemdepizza = [];
ordemdepizza[0] = pizza2.nome
ordemdepizza[1] = pizza3.nome
ordemdepizza[2] = pizza4.nome
ordemdepizza[3] = pizza5.nome
ordemdepizza[4] = pizza6.nome

ordemdepizza.sort()
alert("A ordem de pizzas pelo nome é: " + ordemdepizza)

//b) Ordene as pizzas por preço de forma decrescente.


var ordemdepizzap = ['', '', '', '', ''];
var nomesdaspizzasp = ['', '', '', '', ''];
ordemdepizzap[0] = pizza2.preço
ordemdepizzap[1] = pizza3.preço
ordemdepizzap[2] = pizza4.preço
ordemdepizzap[3] = pizza5.preço
ordemdepizzap[4] = pizza6.preço

ordemdepizzap.sort()

if (ordemdepizzap[0] === pizza2.preço) {
    nomesdaspizzasp[0] = pizza2.nome
}
if (ordemdepizzap[0] === pizza3.preço) {
    nomesdaspizzasp[0] = pizza3.nome
}
if (ordemdepizzap[0] === pizza4.preço) {
    nomesdaspizzasp[0] = pizza4.nome
}
if (ordemdepizzap[0] === pizza5.preço) {
    nomesdaspizzasp[0] = pizza5.nome
}
if (ordemdepizzap[0] === pizza6.preço) {
    nomesdaspizzasp[0] = pizza6.nome
}

if (ordemdepizzap[1] === pizza2.preço) {
    nomesdaspizzasp[1] = pizza2.nome
}
if (ordemdepizzap[1] === pizza3.preço) {
    nomesdaspizzasp[1] = pizza3.nome
}
if (ordemdepizzap[1] === pizza4.preço) {
    nomesdaspizzasp[1] = pizza4.nome
}
if (ordemdepizzap[1] === pizza5.preço) {
    nomesdaspizzasp[1] = pizza5.nome
}
if (ordemdepizzap[1] === pizza6.preço) {
    nomesdaspizzasp[1] = pizza6.nome
}


if (ordemdepizzap[2] === pizza2.preço) {
    nomesdaspizzasp[2] = pizza2.nome
}
if (ordemdepizzap[2] === pizza3.preço) {
    nomesdaspizzasp[2] = pizza3.nome
}
if (ordemdepizzap[2] === pizza4.preço) {
    nomesdaspizzasp[2] = pizza4.nome
}
if (ordemdepizzap[2] === pizza5.preço) {
    nomesdaspizzasp[2] = pizza5.nome
}
if (ordemdepizzap[2] === pizza6.preço) {
    nomesdaspizzasp[2] = pizza6.nome
}



if (ordemdepizzap[3] === pizza2.preço) {
    nomesdaspizzasp[3] = pizza2.nome
}
if (ordemdepizzap[3] === pizza3.preço) {
    nomesdaspizzasp[3] = pizza3.nome
}
if (ordemdepizzap[3] === pizza4.preço) {
    nomesdaspizzasp[3] = pizza4.nome
}
if (ordemdepizzap[3] === pizza5.preço) {
    nomesdaspizzasp[3] = pizza5.nome
}
if (ordemdepizzap[3] === pizza6.preço) {
    nomesdaspizzasp[3] = pizza6.nome
}

if (ordemdepizzap[4] === pizza2.preço) {
    nomesdaspizzasp[4] = pizza2.nome
}
if (ordemdepizzap[4] === pizza3.preço) {
    nomesdaspizzasp[4] = pizza3.nome
}
if (ordemdepizzap[4] === pizza4.preço) {
    nomesdaspizzasp[4] = pizza4.nome
}
if (ordemdepizzap[4] === pizza5.preço) {
    nomesdaspizzasp[4] = pizza5.nome
}
if (ordemdepizzap[4] === pizza6.preço) {
    nomesdaspizzasp[4] = pizza6.nome
}


alert("A ordem de pizzas pelo preço é: " + nomesdaspizzasp)
//c) Ordene os ingredientes de cada pizza presente no array.

alert("Ingredientes da pizza 1 ordenados: " + pizza2.ingredientes.sort())
alert("Ingredientes da pizza 2 ordenados: " + pizza3.ingredientes.sort())
alert("Ingredientes da pizza 3 ordenados: " + pizza4.ingredientes.sort())
alert("Ingredientes da pizza 4 ordenados: " + pizza5.ingredientes.sort())
alert("Ingredientes da pizza 5 ordenados: " + pizza6.ingredientes.sort())