
/*
1

Crie uma pasta denominada arrays. No interior da pasta, crie os códigos de 
respostas para os
seguintes exercícios:
1. Elabore um array denominado 
caes
, contendo as seguintes raças: Boxer, 
Buldogue, Labrador,
Poodle, Pastor, Beagle, Pug, Galgo e Husky. Faça:
a) Mostre na tela o número de cães presentes na lista.
b) Mostre o primeiro e último cães da lista.
c) Mostre natela somente os cães que iniciem com a letra ‘B’.
d) Conte e mostre na tela o número de cães que iniciam com a letra ‘P’.




*/


//1


var caes = ['Boxer', 'Buldogue', 'Labrador',
    'Poodle', 'Pastor', 'Beagle', 'Pug', 'Galgo', 'Husky'];


    //a

    alert("O numero de cães presentes na lista é " + caes.length);

    //b

    alert("O primeiro cão da lista é o " + caes[0] + ".\nO último cão da lista é o " + caes[caes.length-1]);

    //c

    var caescomletrab=[]

    let i=0;
    for(let x=0; x<caes.length-1; x++){
        if(caes[x].charAt(0)==="B"){
            caescomletrab[i]=caes[x]
            i++;
        }
    }

    alert("O caẽs cujos nomes iniciam com a letra B são " + caescomletrab);
    
    //d
    
    
    var caescomletrap = []
    
    let k = 0;
    for (let h = 0; h < caes.length - 1; h++) {
        if (caes[h].charAt(0) === "P") {
            caescomletrab[k] = caes[h]
            k++;
        }
    };
    
    alert("O caẽs cujos nomes iniciam com a letra P são " + caescomletrab +"\nE eles são " + (k) + " cães");

//2

/*2. Crie um array vazio denominado outrosCaese faça:
a) Elabore uma string denominada
listaDeCaes
contendo os seguintes cães
separado
s por ‘-’:
yorkshire, rottweiler, maltês, collie, basset, cocker e pinscher.
    b) Insira os elementos no array
outrosCaes
a partir dos dados contidos na
string
listaDeCaes.
    c) Mostre uma string na tela apresentando o conteúdo do array 
outrosCaes.
        d) Crie um
novo array denominado
todosOsCaes
o qual deverá ser resultante
da concatenação das
listas
caes,criada no exercício anterior, com a lista
outrosCaes

*/

var outrosCaes= [];

//a

var listaDeCaes = 'yorkshire-rottweiler-maltês-collie-basset-cocker-pinscher'

//b

outrosCaes= listaDeCaes.split('-');

//c

alert("O conteúdo do array outrosCaes é " + outrosCaes);

//d


var todosOsCaes=[];

todosOsCaes= caes.concat(outrosCaes)

alert(todosOsCaes)
