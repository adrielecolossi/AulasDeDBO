/*
4

1–
Um funcionário de uma empresa recebe aumento sa
larial anualmente.
Sabe-se que:
• Esse funcionário foi contratado em 2010, com salário inicial de R$1000,00;
• Em 2011 recebeu aumento de 1,5% sobre seu salário inicial;
• A partir de 2012 (inclusive), os aumentos salariais sempre corresponderam ao
dobro do percentual do ano anterior.
Faça um programa que determine o salário atual desse funcionário.
2–
Faça um programa que calcule a soma dos primeiros 50 números pares.
3–
Faça um programa onde o usuário possa escolher qual a tabuada que se
deseja imprimir.
Exiba a tabuada desse número de 1 a 10.
*/



let s = (1000 * 101.5) / 100;
let a = parseInt(prompt("Digite o ano atual:"));
let pi = 1.5
let c = a - 2011;
if (a > 8) {
    a = 8;
}
let c2 = 0;
while (c2 <= c) {
    pi = pi * 2;
    console.log(pi);
    s = (s * (100 + pi)) / 100;
    console.log(s);
    c2++;
}
alert("O salário atual do funcionário é de R$" + s.toFixed(2));



//2

let soma=0;

for(let numeros=0; numeros<=50; numeros++){

    if(numeros%2==0){
        soma+=numeros;
    }
}

alert("A soma dos 50 primeiros numeros pares é " + soma);
//3

let num= prompt("Diga qual tabela deseja imprimir");

let tabela='';
for(let w=1; w<=10; w++){
 tabela+=w+"X"+num+" = "+ (num*w) + "\n"
}
alert(tabela)

