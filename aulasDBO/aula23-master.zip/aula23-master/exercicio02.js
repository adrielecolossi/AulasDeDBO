/*
1. Escreva um programa que leia uma string e informe ao usuário o número de
caracteres contidos.
2. Crie um programa que leia o nome de uma pessoa e mostre na tela somente
se o nome iniciar com a letra ‘A’, tanto faz maiúscula como minúscula.
3. Construa um programa que leia seu nome completo e mostre na tela
somente o primeiro nome.
4. Escreva um programa que leia o nome da pessoa e calcule quantas vogais
estão presentes.
5. Elabore um programa que leia um código binário, na forma de uma string,
exemplo “01010011001”. O programa deverá contar o número de dígitos “1”
presentes na string.
6. Escreva um programa que leia uma frase qualquer, após deverá substituir
todas as ocorrência da letra “a” por“@”.
7. Crie um programa que leia o seu nome e mostre-o ao contrário.
8. Escreva um programa que leia seu nome completo e mostre na tela somente
as iniciais em maiúsculas.
*/

//1

var string= prompt("Escreva uma string");

alert("O número de caracteres contidos é " +string.length) //se espaço conta como caracter

//2

let nome= prompt("Escreva o nome de uma pessoa");

if(nome.charAt(0)=="A" || nome.charAt(0)=='a'){
    alert("O nome " + nome + " começa com a letra A");
}

//3

let ncompleto= prompt("Escreva um nome completo, separando entre espaços cada parte dele.");

ncompleto= ncompleto.split(" ");

alert("O primeiro nome é " + ncompleto[0])

//4

let nome2= prompt("Escreva o nome da pessoa que você quer contar quantas vogais há presente");
let vogais=0;
let vogaiss=['a','A','e','E','i','I','o','O','u','U']

for(let k=0; k<nome2.length; k++){ 
    if(vogaiss.indexOf(nome2.charAt(k))!==-1){
        vogais++
    }
}

alert("O nome de vogais presentes nesse nome é " + vogais);

//5

let binario= prompt("Digite um número binario");

let totaldeum=0;
for(let u=0; u<binario.length; u++){
    if(binario[u]== "1"){
        totaldeum++;
    }
}

alert("O total de 1 presente nesse número binário é " + totaldeum);

//6

let frase= prompt("Digite uma frase");

let frasemudada= '';
for(let o=0; o<frase.length; o++){
    if(frase[o]=="a"){
     frasemudada+='@'
    } else{
     frasemudada+= frase[o]
    }
}

alert(frasemudada);

//7

let nome3= prompt("Digite seu nome");

let arr= nome3.split('');

arr= arr.reverse();

arr= arr.join('')

alert("Seu nome ao contrário é "+ arr);

//8

let nome4= prompt("Digite seu nome completo");

nome4= nome4.split(" ");

let iniciais='';

let excluir= ["da", "de", "do"];

for(let q=0;q<nome4.length; q++){
    if(excluir.indexOf(nome4[q])===-1){
        iniciais+= nome4[q].charAt(0);
    }
}

iniciais= iniciais.toUpperCase()
alert(iniciais);

