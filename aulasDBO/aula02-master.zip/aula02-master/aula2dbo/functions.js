console.log('functions.js')

//rotate

let txt= 'informatica';
//algoritmo(lógica)

txt= txt.charAt(txt.length-1) + txt.substr(0, txt.length-1)

console.log(txt) //ainformatic
console.log(txt==='ainformatic') //true
console.assert(txt==='ainformatic') //é uma assertiva


console.log(txt==='rsif'); //true

/*uma função guarda um algoritmo(encapsula), voce cria o algoritmo e usa ele em varios lugares


seu formato é o seguinte:

entrada(parâmetros)
"miolo" (corpo do algoritmo)
saída(retorno)

*/

function rotate(txt){
   const resp= txt[txt.length-1] + txt.substr(0,txt.length-1);
   return resp;
}

let palavra= 'laptop';
let teste= rotate(palavra);  //não é necessario que essa var tenha o nome de rotate
//podemos colocar rotate('laptop) que ele ira funcionar

console.log(teste);