let rotate = function(txt, horario = true){ //se não botarmos outra coisa, ele vai ser true
   // debugger; //ele vai pausar a execução aqui
   //debugger é o mesmo que selecionar a linha com um clique no sources e recarregar a pagina
    const len= txt.length;
    if(horario===true){   //temos que botar o true, um numero entra false uma string entra false etc
        
        return txt[len-1] + txt.substr(0, len-1)
        
    } else{
        
        return  txt.substr(1,len) + txt[0];
    }

 
 }
//truthy, falsy (true, false)
 console.log(rotate('ifrs')); //true quer dizer que ele é horario
//se colocarmos false, 0, undefined, null, '', NaN ele retorna frsi
//qualquer outra coisa, ele vai ser horario pq colocamos horario=true nos parâmetros



 /*
 o que é falsy(falso)?
 
 false, 0, undefined, null, '', NaN

 O que não é isto é true
 */


const v =3;
if(v){
    console.log('V é True') //V é True
}

const k=[]
if(k){
    console.log('K é True') //K é True
}

const h=0
if(h){
    console.log('h é True') //não retorna nada
}

//  https://developer.mozilla.org/pt-BR/docs/Glossario/