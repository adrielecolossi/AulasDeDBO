//especificação
function mediana(x) {


    if (x.length>0) {
        if ((x.length) % 2 == 0) {
            let media = (x.length / 2)
            let resp = (x[media - 1] + x[media]) / 2
            return resp;
        } else {
            let media = Math.floor(x.length / 2)
            return x[media];
        }
    } else {
        return undefined;
    }


}

const idades = [7, 15, 20, 22, 34, 40, 70];

//mediana

const m = mediana(idades);
console.log(m); //22
console.log(m === 22); //true


const idades2 = [20, 24, 26, 40];
console.log(mediana(idades2) === 25) //true
console.log(mediana([34, 40, 82]) === 40) //true
console.log(mediana([1000, 2000, 3000, 4000]) === 2500) //true
console.log(mediana([])) //undefined
console.log(mediana([123]) === 123) //true



//espesificação: split de string
//restrição: não pode usar o split

const str= 'abc,def,ghi';

function split(y,z){

    let vetor=[];
    let c=0;
    let d=0;
 while(y.charAt(c)!=z){

vetor[d]+=y.charAt(c)

if(y.charAt(c)==z){    
    d++
}

c++
 }






}

const vet= split(str, ',');
console.log(vet);
//console.log(vet.length ===3);
console.log(vet[0] === 'abc');
console.log(vet[1] === 'def');
console.log(vet[2] === 'ghi');
const vet2 = split(str, 'e');
console.log(vet2.length ===2);
console.log(vet2[0]=== 'abc,d')
console.log(vet2[1]=== 'f,ghi')
