let twice = function(n){
 if(typeof(n)==='number'){
    return 2*n;
 }
 if(typeof(n)==='string'){
     return n+n
 }

 if(Array.isArray(n)){
     return n.concat(n)
 }

}; //é a mesma coisa que escrevemos abaixo

let duasvezes= twice;
//console.log(duasvezes(3)) //retorna 6 
/* function twice(n) {  //é elevado(hoisting), nesse caso nós não vemos mas o javascript troca essa ordem, ele coloca sozinho a função embaixo
   return 2* n;
 }
 podemos usar uma função como parametro para outra, ja que cada função é uma var tambem
*/
 let x=[8,7];
let r= twice(x);
//nomefun(par1, par2, parn) é a declaração tradicional 
//ctrl shift copia 
//lamda é o simbolo de função
//console.log(r) //retorna 16
//agora se tivermos um vetor ele vai dar indefinido

console.log(twice('ifrs')) //ifrsifrs, ele entra na segunda condição
console.log(twice([1,2])) // [1,2,1,2] 
console.log(twice()) //retorna undefined