/*
const maos = {
    pedra: 'pedra',
    papel: 'papel',
    tesoura: 'tesoura',
    lagarto: 'lagarto',
    spock: 'spock'
};
*/

//console.log(maos); // {pedra:'pedra'...}

const jokenpo = { // solução Orientada a Objetos
    maoJogadorUm: null, // não temos definida ainda
    maoJogadorDois: null, // propriedade: chave/valor 
    maos: { // aqui esta a logica de quem vence quem
        pedra: {
            vence: {
                tesoura: 'quebra',
                lagarto: 'esmaga'
            }
        },
        papel: {
            vence: {
                pedra: 'embrulha',
                spock: 'refuta'
            }
        },
        tesoura: {
            vence: {
                papel: 'corta',
                lagarto: 'decapita'
            }
        },
        lagarto: {
            vence: {
                papel: 'come',
                spock: 'envenena'
            }
        },
        spock: {
            vence: {
                tesoura: 'quebra',
                pedra: 'vaporiza'
            }
        }
    },
    jogar: function () { // é um metodo(propriedade com uma function) de 'maos
        if (this.maoJogadorUm === null) {
            throw new Error('Jogador um não escolheu uma mão'); // 'jogar'
            // ela lança uma exceção, não é um erro
        }
        if (this.maosJogadorDois === null) {
            throw new Error('Jogador dois não escolheu uma mão');
            // nesse exemplo não acontece ja que é contra o computador
        }
        if (this.maoJogadorUm === this.maoJogadorDois) {
            return {
                vencedor: 0,
                texto: 'Empatou'
            };
        }
        const mao1 = this.maoJogadorUm;
        const mao2 = this.maoJogadorDois;
        if (jokenpo['maos'][mao1]['vence'][mao2]) {
            return {
                vencedor: 1, // foi o jogador um que ganhou
                texto: `${mao1} ${jokenpo['maos'][mao1]['vence'][mao2]} ${mao2}`
                // interpolou mao1( por ex spock) + a forma como matou
                // (como esta mostrado nos consoles abaixo) + (jogador dois)
            };
        } else {
            // se chegou ate aqui, nao perdeu nos return
            // anteriores, é porque um ou o outro ganhou
            return {
                vencedor: 2, // foi o jogador um que ganhou
                texto: `${mao2} ${jokenpo['maos'][mao2]['vence'][mao1]} ${mao1}`
                // interpolou mao1( por ex spock) + a forma como matou
                // (como esta mostrado nos consoles abaixo) + (jogador dois)
            };
        }
    }
};

// lógica para o humano selecionar uma mão
const botaoJogar = document.querySelector('button'); // só temos um botão
console.log(botaoJogar);
const divHumano = document.querySelector('div#humano');
let maoSelecionada = null;
const selecionarMao = function (e) {
    //console.log(e.target); //há varios consoles, como debug, warn, dir(de diretório), table(quando temos um vetor,e ele coloca o vetor em uma tabelinha) 
    if (e.target.classList.contains('mao')) {
        //metodo contains: se na liste de classes da coisa que você clicou tem uma class mao
        if (e.target === maoSelecionada) {
            e.target.classList.remove('selecionada');
            maoSelecionada = null;
        } else {
            if (maoSelecionada !== null) {
                maoSelecionada.classList.remove('selecionada');
            }
            maoSelecionada = e.target;
            maoSelecionada.classList.add('selecionada');;
        }
        if (maoSelecionada) { //se ela for diferente de null, entra
            botaoJogar.removeAttribute('disabled')
            // removeAttr e setAttribute
        } else {
            botaoJogar.setAttribute('disabled', 'disabled');
        }
    }

};
// temos className
// e.target.className+= 'outra class';
// e.target.classList.add('outra class');

divHumano.addEventListener('click', selecionarMao);
// botão jogar
// função anônima para o evento
// todo evento é um CALLBACK
// é o chamado principio hollywood, se precisarmos, we call back
botaoJogar.addEventListener('click', function (e) {
    /*
    // javascript é assincrono, o tempo que executa não é o tempo na listagem
    // algumas coisas dependem que o evento aconteça
    
    document.querySelectorAll('div#computador img.mao')[1].classList.add('carregando')
 //vai comecar a girar
 document.querySelectorAll('div#computador img.mao')[1].classList.remove('carregando') 
 // vai parar de girar
 */

   //  document.querySelectorAll('div#computador img.mao')
    // .forEach(function (el) {
    // el.classList.add('carregando');
    //});

    //arrow function
    document
        .querySelectorAll('div#computador img.mao')
        .forEach((img) => img.classList.add('carregando')); //é uma função em linha com =>

       jokenpo.maoJogadorUm= maoSelecionada.getAttribute('alt');
       
       console.dir(jokenpo); //dir é útil para objetos
       
       const maos= ['pedra','papel', 'tesoura', 'lagarto', 'spock'];
       const indice= [Math.floor(Math.random()*5)]
        jokenpo.maoJogadorDois = maos[indice];

        setTimeout(function(){
    
            document
        .querySelectorAll('div#computador img.mao')
        .forEach((img) => img.classList.remove('carregando'));


        document
        .querySelector(`div#computador img[alt= ${jokenpo.maoJogadorDois}]`)
        .classList.add('selecionada')
        //document.querySelector('div#computador img[alt' + jokenpo.maoJogadorDois + ']')
        //.classList.add('selecionada') 
        
        
        //fizemos a interpolação para saber qual mão vai ser 
          //mesma coisa que 'div#computador img[alt' + jokenpo.maoJogadorDois + '].classList.add('selecionada')
        const resp= jokenpo.jogar();
        document.querySelector('div#resultado')
        .textContent= resp.texto;
        }, 3000)  //função, tempo em milisegundos(3 mil milisegundos é 3s)

        
        


    //const maos= document.querySelectorAll('div#computador img.mao');
    //for(const mao of maos){
    //   mao.classList.add('carregando');
    //}
});

// lógica para o computador selecionar uma mão
// apresentar quem ganhou





/* no console do google
jokenpo.maoJogadorUm='papel'
"papel"
jokenpo.maoJogadorDois='pedra'
"pedra"
jokenpo.jogar()
{vencedor: 1, texto: "papel embrulha pedra"}

*/

/*
const mao1 = 'papel'; //vai buscar la no objeto maos que temos no inicio
//const mao1=maos.spock   mesma coisa
const mao2 = 'spock';


// traversing(é percorrer a estrutura, 'navegar' nela)
console.log(jokenpo.maos.lagarto.vence.papel); //come

console.log(jokenpo['maos']['lagarto']['vence']['papel']); //come
// vetor é util para criarmos algo que pode ser estendido
// ou reduzido, o que não é o caso

console.log(jokenpo['maos'][mao1]['vence'][mao2]);
//refuta ja que spock ganha do papel
console.log(jokenpo['maos'][mao2]['vence'][mao1]);
 //undefined ja que papel n ganha do spock
console.log(jokenpo['maos'][mao2]['vence'][mao2]);
 //undefined ja que ele n ganha dele mesmo

console.log(Object.keys(jokenpo.maos))
// ['pedra','papel','tesoura','lagarto','spock']
for (const m of Object.keys(jokenpo.maos)) {
    // pra pegar as chaves do objeto(no caso pedra, papel, tesoura, lagarto)
    console.log(m); //pedra, papel, tesoura, lagarto, spock
    for (const v of Object.keys(jokenpo.maos[m].vence)) {
    // console.log(v); //tesoura,lagarto, pedra,
    // spock, papel, lagarto, papel, spock, tesoura, pedra
       console.log(m,jokenpo.maos[m].vence[v] ,v)
  //ta mostrando todas as coisas
  //(...tesoura decapita lagarto, lagarto come papel...)
    }
}

*/


