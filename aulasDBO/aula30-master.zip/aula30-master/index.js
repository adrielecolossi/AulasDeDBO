console.log('index.js');

catalogo = {
    add: function () {
        // Nome, resumo, nota e data de lançamento
        let name =
            localStorage.setItem('name', name);
    },
    pesquisar: function () {

    }
}




const buttonGenerate = document.querySelectorAll('button')[2];
buttonGenerate.addEventListener('click', acrostic.generate);