//uml: linguagem que utilizamos tanto para banco quanto para a criação de sistemas
//modelador unificado de linguagem -> uml
//são aquelas espécies de diagramas que vemos em imagens que orientam a programação

/*
Trabalhamos orientados a objeto principalmente devido ao reuso de dados. Não precisamos, para cada cliente que entra em um banco por exemplo, recriar todo o sistema.

O diagrama por desenho representa qual classe herda de qual.


*Modularidade
-Decomposição de um problema em pequenos pedaços para gerenciar sua complexidade, cada conceito é chamado de um módulo.

*Namespaces
    Um recipiente que permite empacotar todas as funcionalidades em um nome único e específico da aplicação.

*Classe
    Define as características do objeto. Uma classe é uma definição modelo das propriedades e métodos de um objeto.

*Objeto
    Um exemplar de uma classe.

*Atributo
    Uma característica do objeto, como cor, modelo, fabricante se estivemos representando um veículo, por exemplo.

*Método
    Uma ação do objeto, como ligar, desligar, frear se estivemos representando um veículo, por exemplo. É uma subrotina ou função associada a uma classe.

*Construtor
    Um método chamado assim que um novo exemplar do objeto for criado. Ele geralmente tem o mesmo nome da classe que o contém.

*Herança
    Uma classe pode herdar características de outra classe.
- É a criação de uma hierarquia de abstração
-Permite ordenar hierarquias
-Base conceitual que permite extensibilidade de software

*Encapsulamento
    Uma maneira de agrupar os dados e os métodos que usam os dados.
    -É o que usamos para envolver o código e ningúem poder mexer em nosso software, por exemplo o botão de mudança de volume de uma televisão, há um software dentro dele mas o usuário não precisa saber o que há dentro 

*Abstração
    A conjunção de herança complexa, métodos, propriedades de um objeto devem refletir adequadamente um modelo da realidade.
    -Construção de um modelo para a realidade

*Polimorfismo
    Diferentes classes podem definir o mesmo método ou propriedade.


Classe
=======

-Descrição dos objetos com propriedades e comportamentos comuns
-Suprime o que não interessa


Polimorfismo
============

-Escondendo diferentes implementações através de uma unica interface
Mecanismo por meio do qual selecionamos as funcionalidades utilizadas de forma dinâmica por um programa no decorrer de sua execução.

interface
==========

Definem um tipo especificando apenas a assinatura de seus metodos

Classe abstrata= é a que não possui instância, ela não tem objetos, não instanciamos (formamos um objeto)

Simply define an interface using Interface and call implement on an object to check if it implements the given interface.

const Hello = {
    greeting: 'hello'
    wave () {}
}
const Introduction = Interface('Introduction')({
    greeting: type('string')
    handshake: type('function')
}, { error: true })

const HelloIntroduction = implement(Introduction)(Hello) // throws an erro


Pacote
======

-Mecanismo para organizar elementos em grupo.

Coesão e Acoplamento
===================

Coesão está, na verdade, ligado ao princípio da responsabilidade única, que foi introduzido por Robert C. Martin no inicio dos anos 2000 e diz que uma classe deve ter apenas uma única responsabilidade e realizá-la de maneira satisfatória, ou seja, uma classe não deve assumir responsabilidades que não são suas . Uma vez sendo ignorado este princípio, passamos a ter problemas, como dificuldades de manutenção e de reuso. 

Sistemas devem ter baixo Acoplamento e auta coesao.

Subsistema
============


Relacionamentos:
================

Associação
----------

Relação estrutural entre classes

Agregação
---------

O todo possui um nivel de abstração maior que a parte 

Composição
----------

O todo é responsável pela criação da parte

*/