//Document Object Model
//Modelo de Objetos do Documento

function troca() {
    let li = document.body.children[2].children[1];
    console.log(li);
    //siblings é o irmãos com nextElementSibling ou document.body.children[2].children[1].previousElementSibling;
    //o segundo filho do terceiro filho do body
    li.textContent = 'Geografia';   //Usando javascript pra alterar o HTML
    li.style.color = 'lime';  //Usando javascript pra alterar o CSS
    li.parentElement.style.backgroundColor = 'black';
}

//agora ele so troca se invocarmos a função troca, colocando no console.log troca()
//document.body.children[5] é o button

const button= document.body.children[5]
button.onclick= troca;




