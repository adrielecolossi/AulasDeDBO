/*
1. Cria uma Classe Pessoa, contendo os atributos encapsulados, com seus respectivos seletores (getters) e modificadores (setters), e ainda o 
construtor padrão e pelo menos mais duas opções de construtores conforme sua percepção. Atributos: String nome; String endereço; String telefone;
*/

class Pessoa { //ela é util pois não especifica uma, é uma definição geral de o que é ser uma pessoa, e usamos ela para criar as pessoas
    constructor(nome, endereco, telefone) {
        this._Nome = nome;
        this._Endereco = endereco;
        this._Telefone = telefone;
    }
    set Nam(value) {
        this._Nome = value.toUpperCase();
    }
    get Nam() {
        return this._Nome;
    }
    set Ad(value) {
        this._Endereco = value.toUpperCase();
    }
    get Ad() {
        return this._Endereco;
    }
    set Phone(value) {
        this._Telefone = value.toUpperCase();
    }
    get Phone() {
        return this._Telefone;
    }

}


var person1 = new Pessoa("um", "Rua Um", "1");
var person2 = new Pessoa("dois", "Rua Dois", "2");
var person3 = new Pessoa("três", "Rua Três", 3);

console.log(person1);
console.log(person2);
console.log(person3);


/*2. Considere, como subclasse da classe Pessoa (desenvolvida no exercício anterior) a classe Fornecedor. 
Considere que cada instância da classe Fornecedor tem, para além dos atributos que caracterizam a classe 
Pessoa, os atributos valorCredito (correspondente ao crédito máximo atribuído ao fornecedor) e 
valorDivida (montante da dívida para com o fornecedor). Implemente na classe Fornecedor, para além dos 
usuais métodos seletores e modificadores, um método obterSaldo() que devolve a diferença entre os valores 
dos atributos valorCredito e valorDivida. Depois de implementada a classe Fornecedor, crie um programa de 
teste adequado que lhe permita verificar o funcionamento dos métodos implementados na classe Fornecedor e 
os herdados da classe Pessoa.
*/
// valordivida = undefined;

//valorCredito = undefined;


class Fornecedor extends Pessoa {
    constructor(nome, endereco, telefone, valorCredito, valorDivida) {
        super(nome, endereco, telefone);
        this._valorCredito = valorCredito;
        this._valorDivida = valorDivida;
    }
    get valorCredito() {
        return this._valorCredito
    }
    set valorCredito(Novo) {
        this._valorCredito = Novo;
    }
    get valorDivida() {
        return this._valorDivida
    }
    set valorDivida(Novo) {
        this._valorDivida = Novo;
    }
    obterSaldo() {
        console.log(this._valorCredito - this._valorDivida);
        return (this._valorCredito - this._valorDivida);
    }
}

var person4 = new Fornecedor("três", "Rua Três", 3, 40, 10)
console.log(person4)
person4.obterSaldo(); //com o console.log, podemos ver que é 30

/*
3. Considere, como subclasse da classe Pessoa, a classe Empregado. Considere que cada instância da classe
Empregado tem, para além dos atributos que caracterizam a classe Pessoa, os atributos codigoSetor (inteiro),
salarioBase (vencimento base) e imposto (porcentagem retida dos impostos). Implemente a classe Empregado
com métodos seletores e modificadores e um método calcularSalario. Escreva um programa de teste adequado
para a classe Empregado.
*/


class Empregado extends Pessoa {
    constructor(nome, endereco, telefone, codigoSetor, salarioBase, imposto) {
        super(nome, endereco, telefone);
        this._codigoSetor = codigoSetor;
        this._salarioBase = salarioBase;
        this._imposto = imposto;
    }
    get codigoSetor() {
        return this._codigoSetor;
    }
    set codigoSetor(Novo1) {
        this._codigoSetor = Novo1;
    }
    get salarioBase() {
        return this._salarioBase;
    }
    set salarioBase(Novo1) {
        this._salarioBase = Novo1;
    }
    get imposto() {
        return this._imposto;
    }
    set imposto(Novo2) {
        this._imposto = Novo2;
    }
    calcularSalário() {
        console.log(this._salarioBase - this._imposto);
        return (this._salarioBase - this._imposto);
    }
}

var person5 = new Empregado("três", "Rua Três", 3, 2, 40, 8)
console.log(person5)
person5.calcularSalário(); //com o console.log, podemos ver que é 32

/*4. Implemente a classe Administrador como subclasse da classe Empregado. Um determinado administrador tem
como atributos, para além dos atributos da classe Pessoa e da classe Empregado, o atributo
ajudaDeCusto (ajudas referentes a viagens, estadias, ...). Note que deverá redefinir na classe
Administrador o método herdado calcularSalario (o salário de um administrador é equivalente ao salário de
um empregado usual acrescido das ajuda de custo). Escreva um programa de teste adequado para esta classe.
*/


class Administrador extends Empregado {

    constructor(nome, endereco, telefone, codigoSetor, salarioBase, imposto, ajudaDeCusto) {
        super(nome, endereco, telefone, codigoSetor, salarioBase, imposto);
        this._ajudaDeCusto = ajudaDeCusto;
    }
    get ajudaDeCusto() {
        return this._ajudaDeCusto;
    }
    set ajudaDeCusto(Novo3) {
        this._ajudaDeCusto = Novo3;
    }
    calcularSalário() {
        console.log(this._salarioBase + this._ajudaDeCusto);
        return (this._salarioBase + this._ajudaDeCusto);
    }
}


var person6 = new Administrador("três", "Rua Três", 3, 2, 40, 8, 10)
console.log(person6)
person6.calcularSalário(); //com o console.log, podemos ver que é 50, modificando o original.

/*
5. Implemente a classe Operario como subclasse da classe Empregado. Um determinado operário tem como
atributos, para além dos atributos da classe Pessoa e da classe Empregado, o atributo
valorProducao (que corresponde ao valor monetário dos artigos efetivamente produzidos pelo operário) e
comissao (que corresponde à porcentagem do valorProducao que será adicionado ao vencimento base do operário).
Note que deverá redefinir nesta subclasse o método herdado calcularSalario (o salário de um operário é
equivalente ao salário de um empregado usual acrescido da referida comissão). Escreva um programa de teste
adequado para esta classe.
*/

class Operario extends Empregado {

    constructor(nome, endereco, telefone, codigoSetor, salarioBase, imposto, valorProducao, comissao) {
        super(nome, endereco, telefone, codigoSetor, salarioBase, imposto);
        this._valorProducao = valorProducao;
        this._comissao = comissao;

    }
    get valorProducao() {
        return this._valorProducao;
    }
    set valorProducao(Novo4) {
        this._valorProducao = Novo4;
    }

    get comissao() {
        return this._comissao;
    }
    set comissao(Novo4) {
        this._comissao = Novo4;
    }
    calcularSalário() {
        console.log(this._salarioBase + (this._valorProducao * this._comissao / 100));
        return (this._salarioBase + (this._valorProducao * this._comissao / 100)); //não sei como é a fórmula
    }
}



var person7 = new Operario("três", "Rua Três", 3, 2, 40, 8, 10, 10)
console.log(person7)
person7.calcularSalário(); //com o console.log, podemos ver que é 41, modificando o original.

/*
6. Implemente a classe Vendedor como subclasse da classe Empregado. Um determinado vendedor tem como
atributos, para além dos atributos da classe Pessoa e da classe Empregado, o atributo
valorVendas (correspondente ao valor monetário dos artigos vendidos) e o atributo comissao
(porcentagem do valorVendas que será adicionado ao vencimento base do Vendedor). Note que deverá
redefinir nesta subclasse o método herdado calcularSalario (o salário de um vendedor é equivalente ao
salário de um empregado usual acrescido da referida comissão). Escreva um programa de teste adequado
para esta classe.
*/


class Vendedor extends Empregado {

    constructor(nome, endereco, telefone, codigoSetor, salarioBase, imposto, valorVendas, comissao) {
        super(nome, endereco, telefone, codigoSetor, salarioBase, imposto);
        this._valorVendas = valorVendas;
        this._comissao = comissao;
    }
    get valorVendas() {
        return this._valorVendas;
    }
    set valorVendas(Novo5) {
        this._valorVendas = Novo5;
    }

    get comissao() {
        return this._comissao;
    }
    set comissao(Novo5) {
        this._comissao = Novo5;
    }
    calcularSalário() {
        console.log(this._salarioBase + (this._valorVendas * this._comissao / 100));
        return (this._salarioBase + (this._valorVendas * this._comissao / 100));
    }
}
var person8 = new Vendedor("três", "Rua Três", 3, 2, 40, 8, 10, 80)
console.log(person8)
person8.calcularSalário(); //com o console.log, podemos ver que é 48, modificando o original.

console.log(Pessoa);