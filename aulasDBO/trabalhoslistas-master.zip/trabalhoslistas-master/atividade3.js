/*
1- Crie uma hierarquia de classes conforme abaixo com os seguintes atributos e comportamentos (observe a tabela), utilize os seus conhecimentos
e distribua as características de forma que tudo o que for comum a todos os animais fique na classe Animal:
*/


class Animal{
    constructor(nome, idade, som) {
        this._Nome = nome;
        this._Idade = idade;
        this._Som = som;
    }
    set Name(value) {
        this._Nome = value.toUpperCase();
    }
    get Name() {
        return this._Nome;
    }
    set Age(value) {
        this._Idade = value;
    }
    get Age() {
        return this._Idade;
    }
    set Sound(value){
        this._Som = value;
    }
    get Sound(){
        return this._Som;
    }

    emitirSom(){
        console.log("O animal " + this._Nome+" emite o som " + this._Som);
    }
}
class Cachorro extends Animal { 

    constructor(nome, idade, som,) {
        super(nome, idade, som);
    }
    correr() {
        console.log("O cachorro está correndo.");
    }
}

class Cavalo extends Animal {

    constructor(nome, idade, som) {
        super(nome, idade, som);
    }
        correr() {
            console.log("O cavalo está correndo.");
        }
    
}

class Preguica extends Animal {

    constructor(nome, idade, som) {
        super(nome, idade, som);
    }
    escalar() {
console.log("A preguiça está subindo na arvore.");
    }

}

/*
Implemente um programa que crie os 3 tipos de animais definidos no exercício anterior e invoque o método que emite o som de cada um de 
forma polimórfica, isto é, independente do tipo de animal.
*/

var cachorro= new Cachorro('cachorro', 1, 'auau', 10);
cachorro.emitirSom();

var cavalo= new Cavalo('cavalo', 2, 'irinho', 20);
cavalo.emitirSom();

var preguica= new Preguica('preguica', 3, 'uoon', 1);
preguica.emitirSom();

/*
Implemente uma classe Veterinario que contenha um método examinar() cujo parâmetro de entrada é um Animal, quando o animal for examinado ele
deve emitir um som, passe os 3 animais com parâmetro.
*/

class Veterinario extends Animal{ //não ha necessidade de usar get e set
    constructor(nome, idade, som){
        super(nome, idade, som)
        this._Nome= nome;
        this._Som= som;
    }
    examinar(){
      console.log("O "+this._Nome +" examinado emitiu o som " + this._Som);
    }
}

//Animal.prototype.examinar= Veterinario.examinar
//Animal.prototype.examinar = function () {
//    console.log("O "+this._Nome +" examinado emitiu o som " + this._Som);
//}

var cachorro2= new Veterinario('cachorro2',1, 'auau');
cachorro2.examinar();
var cavalo2 = new Veterinario('cavalo2', 1, 'irinho');
cavalo2.examinar();
var preguica2 = new Veterinario('preguica2', 1, 'uoon');
preguica2.examinar();


/*
4- Crie uma classe Zoologico, com 10 jaulas (utilize um array) coloque em cada jaula um animal diferente, percorra cada jaula e emita o som e,
 se o tipo de animal possuir o comportamento, faça-o correr.
*/

class Zoologico{
  constructor(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10){
      this.jaulas= [a1,a2,a3,a4,a5,a6,a7,a8,a9,a10];
  }
    tudo() {
        let somm;
        for(let h=0;h<10;h++){
            if(this.jaulas[h]=='cachorro'){
                somm="auau"
            } else{
                if(this.jaulas[h]=='cavalo'){
                somm="irinho";
                } else{
                    somm="uuiu"
                }
            }
            if(this.jaulas[h]=='cachorro' || this.jaulas[h]=='cavalo'){
        console.log("O animal " + this.jaulas[h] + " emite o som " + somm );
        if(this.jaulas[h]=='cachorro'){
            console.log('O cachorro está correndo')
        }else{
            console.log('O cavalo está correndo')
        }        
    } else{
        
        console.log("O animal " + this.jaulas[h] + " emite o som " + somm );
            }
    }
}
}

var zoo= new Zoologico('cachorro','cavalo','cachorro','cavalo','cachorro','cavalo','cachorro','cavalo','cachorro','preguica')

zoo.tudo()

/* 5- Resolva a seguinte situação utilizando os conceitos aprendidos. Uma empresa quer manter o registro da vida acadêmica de todos os 
funcionários, o modelo deve contemplar o registro das seguintes informações, de forma incremental:
5.1 Para o funcionário que não estudou, apenas o nome e o código funcional;
5.2 Para o funcionário que concluiu o ensino básico, a escola;
5.3 Para o funcionário que concluiu o ensino médio, a escola;
5.4 Para o funcionário que concluiu a graduação, a Universidade;
*/

class FuncionarioBasico{
    constructor(nome,codigofuncional){
        this._Nome=nome;
        this._CodigoFuncional=codigofuncional;
    }
}

class EnsinoBasico extends FuncionarioBasico{
    constructor(nome, codigofuncional, escolabasico){
        super(nome, codigofuncional);
        this._EscolaBasico= escolabasico;
    }
}

class EnsinoMedio extends EnsinoBasico{
    constructor(nome, codigofuncional, escolabasico, ensinomedio){
        super(nome, codigofuncional, escolabasico);
        this._EscolaMedio= ensinomedio;
    }
}

class Graduacao extends EnsinoMedio{
    constructor(nome, codigofuncional, escolabasico, ensinomedio, universidade){
        super(nome, codigofuncional, escolabasico, ensinomedio);
        this._Universidade= universidade;
    }
}

/*
6- Estenda o modelo implementado no exercício anterior de forma que todo funcionário possua uma renda básica de R$ 1000,00 e:
6.1 Com a conclusão do ensino básico a renda total é renda básica acrescentada em 10%;
6.2 Com a conclusão do ensino médio a renda total é a renda do nível anterior
acrescentada em 50%;
6.3 Com a conclusão da graduação a renda total é a renda do nível anterior acrescentada em 100%;
6.4 Todos os cálculos são efetuados sempre sobre a última renda obtida.
*/
class FuncionarioBasic {
    constructor(nome, codigofuncional) {
        this._Nome = nome;
        this._CodigoFuncional = codigofuncional;
    }

    _Salario= 1000;
}

class EnsinoBasic extends FuncionarioBasic {
    constructor(nome, codigofuncional, escolabasico) {
        super(nome, codigofuncional);
        this._EscolaBasico = escolabasico;
    }
    _Salario= 1100;
}

class EnsinoMedi extends EnsinoBasic {
    constructor(nome, codigofuncional, escolabasico, ensinomedio) {
        super(nome, codigofuncional, escolabasico);
        this._EscolaMedio = ensinomedio;
    }
    _Salario= 1650;
}

class Graduaca extends EnsinoMedi {
    constructor(nome, codigofuncional, escolabasico, ensinomedio, universidade) {
        super(nome, codigofuncional, escolabasico, ensinomedio);
        this._Universidade = universidade;
    }
    _Salario= 3300;
}

/*
7- Crie um programa que simule uma empresa com 10 funcionários, utilize um array, sendo que a escolaridade dos funcionários é distribuída
da seguinte forma: 40% ensino básico, 40% ensino médio e 20% nível superior. Calcule os custos da empresa com salários totais e por nível
 de escolaridade, utilize a classe funcionário desenvolvida no exercício anterior.
*/

//Escolhi criar uma nova classe para ter novos metodos.

class funcionarios{
    constructor(b1,b2,b3,b4,m1,m2,m3,m4,s1,s2){
        this.empresa = [b1, b2, b3, b4, m1, m2, m3, m4, s1, s2];
    }
    custototal(){
        return (3300*10);
    }
custoescolaridade(){
  return ((1100*4)+(1650*4)+(3300*2)); //Não há necessidade de checar os niveis de escolaridade pois o exercicio ja os diz.
}

}
var Empresa= new funcionarios('basico','basico','basico','basico','medio','medio','medio','medio','superior','superior');



/*
8- Faça uma hierarquia de Comissões, crie as comissões de Gerente, Vendedor e Supervisor. Cada uma das comissões fornece um adicional ao salário conforme abaixo:
8.1 Gerente: R$1500,00
8.2 Supervisor: R$600,00
8.3 Vendedor: R$250,00
*/

//hierarquia em js??
//cada comissão fornece um adicional ao salario, nao precisamos da hierarquia

class Vendedor{
    constructor(salario){
        this._Salario= (salario+250);
    }
}


class Supervisor {
    constructor(salario) {
        this._Salario = (salario + 600);
    }
}


class Gerente {
    constructor(salario) {
        this._Salario = (salario + 1500);
    }
}

/*
9- Adicione a classe funcionário um atributo referente as comissões desenvolvidas no exercício anterior. Corrija o método renda total de forma
que ele some ao valor da renda calculada o adicional da comissão do funcionário.
*/

//criada uma nova 

class funcionarios4{
   constructor(renda,comissao){
       this.renda= renda;
       this.comissao= comissao;
   }

   rendatotal(){
       return (this.renda+ this.comissao);
   }
}

/*
10- Refaça o exercício 7 considerando que 10% dos funcionários são Gerentes,
20% são supervisores e 70% são vendedores.
*/


class funcionarios2 {
    constructor(b1, b2, b3, b4, m1, m2, m3, m4, s1, s2, salario) {
        this.empresa = [b1, b2, b3, b4, m1, m2, m3, m4, s1, s2];
        this.salariobase= salario;
    }
    custototal() {
        return ((this.salariobase*10));
    }
    custoescolaridade() {
        return (((this.salariobase+250)*7) + ((this.salariobase+600)*2) + ((this.salariobase+1500))); //Não há necessidade de checar os niveis de escolaridade pois o exercicio ja os diz.
    }
    
}
var Empresa2 = new funcionarios2 ('vendedor','vendedor', 'vendedor', 'vendedor', 'vendedor', 'vendedor', 'vendedor', 'supervisor', 'supervisor', 'gerente', 1000);

/*
11- Sobreescreva o método toString de forma que ele imprima o nome do funcionário, a comissão e o salário total. Imprima todos os funcionários
da empresa criada no exercício 7.
*/

class funcionarios3 {
    constructor(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10,c1,c2,c3,c4,c5,c6,c7,c8,c9,c10) {
        this.funcionarios = [a1, a2, a3, a4, a5, a6, a7, a8, a9, a10];
        this.comissoes = [c1, c2, c3, c4, c5, c6, c7, c8, c9, c10];
    }
    toString() {
        let somm;
        for (let h = 0; h < 10; h++) {
                if (this.funcionarios[h]=='basico'){
                    renda=1100;
                    console.log('basico');
                }
                if (this.funcionarios[h]=='medio'){
                    renda=1650;
                    console.log('medio');
                }
                if (this.funcionarios[h]=='superior'){
                    renda=3300;
                    console.log('superior');
                }
                console.log(renda+(this.comissoes[h]));
                console.log((this.comissoes[h]));
        }
    }
}

var Empresa5= new funcionarios3('basico','basico','basico','basico','medio','medio','medio','medio','superior','superior', 10,10,10,10,20,20,20,20,30,30);