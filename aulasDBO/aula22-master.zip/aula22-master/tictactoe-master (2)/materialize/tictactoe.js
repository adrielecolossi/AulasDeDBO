console.log("TicTacToe!")

let matriz = [['', '', '', ''], ['', '', '', ''], ['', '', '', '']];


var solo = document.querySelector('button:nth-of-type(1)');
var dupla = document.querySelector('button:nth-of-type(2)');
var jogadores=0;

let usd = [];
let td = document.body.children[7].querySelectorAll('td')
for (let i = 0; i < td.length; i++) {
    let change = false;
    td[i].addEventListener('click', function (e) {
        let y = document.body.children[7].querySelectorAll('td')[i];
        if (document.body.children[7].querySelectorAll('td')[i].textContent === '') {
            usd.push(i);
            y.textContent = "X";
        } else {
            M.toast({ html: 'Você não pode mexer aqui!' })
        }
    })
}

function clique (event) {
    alert(event.target.id); // nodeName);
/*

parseInt(event.target.id)

*/
}
//var table= document.querySelectorAll('table:nth-of-type(1)')
/*
table.addEventListener('click', function(e){
    console.log(e.target);
});

*/

//table.onclick = function (e) { console.log(e.target) };

function sol() { 
    if (jogadores === 0) {
    jogadores = 1;
    } /*else{
     let alterar= prompt('Você já escolheu a sua dificuldade, deseja alterar? (s) ou (n)');
    if(alterar==='s'){
        jogadores=1;
    }
    }*/
    
    //esta infinito 
    for (let jogadas = 0; jogadas < 8; jogadas++) {

        if (jogadas % 2 === 0) {

                alert('jogador 1');
         
           // let clicado = document.body.children[7].querySelectorAll('td')[i];
                    
                   // if (document.body.children[7].querySelectorAll('td')[i].textContent === '') {
                     //   usd.push(i);
                       // y.textContent = "X";
                    //} else {
                     //   M.toast({ html: 'Você não pode mexer aqui!' })
                    //}
            } else {
                alert("jogador 2")
            }

 
        }
    

}

function dupl() { 
  if(jogadores===0){
    jogadores = 2;
  } /*else{
      let alterar = prompt('Você já escolheu a sua dificuldade, deseja alterar? (s) ou (n)');
      if (alterar === 's') {
          jogadores = 2;
      }
  }*/

}


console.log(jogadores)



/*
solo.addEventListener('click', sol());
dupla.addEventListener('click', dupl());
*/

// vamos adcionar a table inteira, já  que ela abrange os td
/*
function sol() { // "e" ou "evt" de evento, não é uma palavra reservada
   jogadores=1;
}

function dupl() { // "e" ou "evt" de evento, não é uma palavra reservada
    jogadores = 2;
}
*/





