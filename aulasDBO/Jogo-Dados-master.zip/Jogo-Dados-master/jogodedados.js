/*

Jogo de dados (Acerte o número seis)
Jogo de dados (Acerte o número seis)
Enunciado: Implemente um jogo que tem como objetivo criar um game em que o jogador
deverá jogar um dado dez vezes. Caso o mesmo acerte o número seis até a décima jogada
exiba uma mensagem de parabéns para o jogador. Caso o jogador não consiga obter o
número seis em suas jogadas exiba uma mensagem de consolo para o jogador.
Regras para implementar o projeto:
 O projeto deve ser implementado em modo texto;
 Deverá ser criado uma classe denominada Dado que representará o dado. A classe deverá
possuir a propriedade número (permitir apenas valores entre 1 e 6), um construtor que
inicia a propriedade número com o valor 1 e um método JogarDado que terá como objetivo
simular o ato de jogar um dado (o valor obtido deverá ser armazenado na variável número.

*/

//Não sei exatamente como implementaria em modo texto, então descrevi o projeto abaixo:

/*


*/

var final= false;

class Dado{
    constructor(){
        this._numero = 1;
    }
    JogarDado(){
        this._numero = (Math.random() * 5 + 1).toFixed(0) 
    }
}

var dado= new Dado;

for(let i=0; i<10; i++){
    if(final===false){
    alert('Os dados rolaram!');
    dado.JogarDado()
    alert("O resultado foi " + dado._numero);    
     if(dado._numero==6){
         final= true;
     }
    }
}

if(final===true){
    alert("Parabéns!")
} else{
    if(final===false){
    alert("Infelizmente você não conseguiu :c")
}
}




