/*1. Crie uma classe de objeto, usando uma função construtora, chamada Carta. A
função construtora recebe os parâmetros pNumero e pNaipe, que são
guardados nos atributos numero e naipe. Esse objeto também tem o método
exibir(),
que mostra as informações da carta na tela de maneira legível (ex. “7 de
paus”).
Exercício 2
*/
function Carta(pNumero, pNaipe) {
    this.numero = pNumero;
    this.naipe = pNaipe;
    this.exibir = function () {
        switch (this.numero) {
            case 1:
                alert("Ás de " + this.naipe);
                break;
            case 11:
                alert("Valete de " + this.naipe);
                break;
            case 12:
                alert("Dama de " + this.naipe);
                break;
            case 13:
                alert("Rei de " + this.naipe);
                break;
            default:
                alert(this.numero + " de " + this.naipe);
                break;
        }
    }
}

/*2.Usando a classe Carta criada anteriormente, faça um programa que tenta
adivinhar uma carta que o jogador está pensando. Como? No início, o
computador dá uma instrução: “Pense numa carta do baralho.” Depois, mostra
(usando o método exibir() da
carta) cartas aleatórias uma de cada vez para o
jogador, que deve responder S (sim) ou N (são) se aquela era a carta desejada.
O jogo acaba quando o computador acertar a carta pensada pelo jogador e
mostrar uma mensagem comemorando.
Lembrete: a função para
gerar números aleatórios em JavaScript é
Math.random(). Olhe o jogo
-
didático criado em sala para ver um exemplo de
como usá
-
la
*/

var naipes = ["paus", "ouro", "copas", "espada"];
alert("Pense numa carta. Por exemplo cinco de paus");
prompt();
do {
    var numero = Math.ceil(Math.random() * 13);
    var indNaipe = Math.floor(Math.random() * 4);
    var carta = new Carta(numero, naipes[indNaipe]);
    carta.exibir();
    alert("Essa é a carta que você pensou? digite (s) para sim ou (n) para não");
    var resp = prompt();
} while (resp == "n");
alert("Acertei!");

/* 3.Crie um game de jo
-
ken
-
po. A cada rodada, o jogador vê o menu:
Escolha sua jogada: 1
-
Papel 2
-
Pedra 3
-
Tesoura
O jogo lê a opção do jogador e verifica se é válida. Se for inválida, o jogador
perde a
rodada e o jogo acaba. Se for válida, o computador escolhe uma
resposta aleatória, que é mostrada ao jogador. Se o jogador ganhar, ele pode
jogar mais uma rodada e sua pontuação aumenta. O jogo acaba quando o
jogador perde uma rodada. A pontuação total é m
ostrada no fim do jogo.
*/
var opcoes = ["Papel", "Pedra", "Tesoura"]
var fim = false
var pontos = 0
do {
    alert("Escolha o que vai jogar:\n1 - Papel\n2 - Pedra\n3 - Tesoura");
    var opcao = parseInt(prompt());
    if (opcao > 0 && opcao < 4) {
        var resp = Math.ceil(Math.random() * 3);
        alert("O computador fez sua jogada! Ela foi " + opcoes[resp - 1]);
        if (opcao == resp) {
            alert("Vocês empataram!");
        }
        else if (
            (opcao == 1 && resp == 2) ||
            (opcao == 2 && resp == 3) ||
            (opcao == 3 && resp == 1)) {
            alert("Você ganhou!");
            pontos++;
        }
        else {
            fim = true;
        }
    }
    else {
        fim = true;
    }
} while (fim === false);
alert("Você perdeu! A sua pontuação foi de " + pontos);