/* 1. Elabore um programa para realizar vendas de produtos, para isso escreva uma função construtora
para definição de uma Venda, contendo as seguintes propriedades e métodos:
a)
propriedades:
 totalVendas e totalDescontos, ambas numéricas;
b)
método:
 calculaFaturamento o qual retorna o total de vendas menos os descontos concedidos.
 */

 var Venda= function(totalVendas, totalDescontos){
     this.totalVendas = totalVendas;
     this.totalDescontos= totalDescontos;
 }
/*
 Venda.prototype.calculaFaturamento = function(){
    return (this.totalVendas -this.totalDescontos)
 }

 Farei de outro jeito
*/
 /*
 2. No mesmo programa, declare dois objetos do tipo Venda.
a) leia os totais de vendas e descontos para cada objeto.
b) Mostre na tela o faturamento obtido em cada venda.
*/


var totalVenda1= prompt("Informe o total da primeira venda");
totalVenda1= parseFloat(totalVenda1);

var totalDescontos1= prompt("Informe o total do primeiro desconto");
totalDescontos1= parseFloat(totalDescontos1)

var venda1= new Venda(totalVenda1, totalDescontos1);
var faturamento1= venda1.totalVendas- venda1.totalDescontos;

console.log(venda1)

var totalVenda2= prompt("Informe o total da segunda venda");
totalVenda2= parseFloat(totalVenda2);

var totalDescontos2= prompt("informe o total do segundo desconto");
totalDescontos2= parseFloat(totalDescontos2);
var venda2= new Venda(totalVenda2, totalDescontos2);
var faturamento2 = venda2.totalVendas - venda2.totalDescontos;


alert("O faturamento da primeira venda foi " + faturamento1.toFixed(2))
alert("O faturamento da segunda venda foi " + faturamento2.toFixed(2))

/*3. Elabore outro programa para emitir o salário do funcionário, portanto, crie uma função
construtora para definição de um Funcionário, com as propriedades e métodos:
a)
propriedades
: nome, salarioBase, salarioFinal, totalVendas e comisssao.
b)
métodos:
- calcularComissao que calcula e retorna o valor da comissao da seguinte forma:
    totalVenda * comissao / 100
- calcularSalario que realiza o cálculo do salário final da seguinte forma:
    salarioFinal = salario + calculaComissao( )

*/


var Funcionario= {
   nome: "funcionario",
   salarioBase: 2000, 
   salarioFinal: '',
   totalVendas: 40,
   comissao: 200,
   calcularSalario: function(){
       return this.salarioFinal = this.salarioBase + this.comissao;
   }
   /*CalcularComissao: function calcularcomissao(){
        totalVendas * comissao / 100
    }*/
/* salarioBase= salario*/

}

/*
4. No programa anterior, declare um objeto do tipo Funcionário.
a) leia os dados do funcionário.
b) calcule o salário final do funcionário.
c) Mostre a comissão do funcionário na tela.
d) Mostre o salário final na tela.
*/


Funcionario.nome= prompt("Diga o nome do funcionario");
Funcionario.salarioBase= parseFloat(prompt("informe o salario base"));
Funcionario.comissao=parseFloat(prompt("Diga a comissão"))
alert("Salario final " + Funcionario.calcularSalario());
alert("Comissão " + Funcionario.comissao);