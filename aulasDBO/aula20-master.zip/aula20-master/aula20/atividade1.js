/*

1. Escreva um programa em JavaScript que defina um objeto aluno com as
seguintes características:
a) nome, email, turma, curso e disciplinas.
b) disciplinas é outro objeto, contendo : nome, professor e sala.

*/

const aluno = {
    nome: "Ciclano",
    email: "ciclano@gmail.com",
    turma:  2,
    curso: "Informatica", 
    /*disciplinas: ['Informatica', 'Portugues', 'historia']*/  /* usar vetor para poder declarar varias matérias */
    disciplinas: {
          nome: "Materia1",
          professor: "Fulano",
          sala: 3
    }
};

/*
2. O programa do exercício anterior deverá ler os dados de um aluno e alterar
as chaves correspondentes no objeto.
*/

aluno.nome = prompt("Digite o nome");
aluno.email = prompt("Digite o email");
aluno.turma = prompt("Digite a turma");
aluno.curso = prompt("Digite o curso");


console.log(aluno.nome)
console.log(aluno.email)
console.log(aluno.turma)
console.log(aluno.curso)

/* 3. Mostra todos os dados do aluno na tela. */

alert("Dados do aluno\n\nNome: " + aluno.nome +"\nEmail: " + aluno.email + "\nTurma: " + aluno.turma +"\nCurso: " + aluno.curso );

/*4. Exclua o atributo curso da estrutura do objeto.*/

delete aluno.curso;

/*5. Inclua o nome atributo bloco contendo o valor “Bloco de laboratórios”*/

aluno.bloco= "Bloco de laboratorios";
aluno['bloco']= "Bloco de laboratorios";