const dotNotation = {
    prop1: "Sou uma propriedade que será acessada usando dot notation",
    metodo: function(){
        return "Sou o retorno de um metodo, ou seja, uma função dentro de um objeto"
    }
}

//Acessando a propriedade e o metodo
//console.log( dotNotation.prop1)
//console.log(dotNotation.metodo())

//Declarando uma propriedade e depois um novo método

dotNotation.prop2= "Sou uma outra propriedade com o valor tipo string"
dotNotation.metodo2= () => "Sou o retorno de outro metodo"

/*
dotNotation.metodo3 = function () {
    return "Sou o retorno de um metodo, ou seja, uma função dentro de um objeto"
}

*/

//acessando os novos componentes

console.log(dotNotation.prop2)
console.log(dotNotation.metodo2())

/*

arrow functions

-estrutura é =>

tiramos o "function" e colocamos =>
apenas isso
*/

/*

function Car(make, model, year) {
  this.make = make;
  this.model = model;
  this.year = year;
}

var car1 = new Car('Eagle', 'Talon TSi', 1993);

console.log(car1.make);
// expected output: "Eagle"

*/

/*

uso do this
-----------

let user = {
  name: "John",
  age: 30,

  sayHi() {
    // "this" is the "current object"
    alert(this.name);
  }

};

user.sayHi(); // John


OU

let user = {
  name: "John",
  age: 30,

  sayHi() {
    alert(user.name); // "user" instead of "this"
  }

};

*/


function Ventilador(VelMax){

    this.velocidademaxima= VelMax;
    this.ligado=false;
}

//Instâncias 

//Para criar a instância de um objeto do tipo "ventilador" usamos a palavra reservada "new" seguida da chamada da função
 
const ventilador1= new Ventilador(3)

//acessando propriedades

//para acessarmos propriedades, como ja foi visto, usaremos o "."

console.log(ventilador1.velocidademaxima) //3

//Diferente de outras linguagens orientadas a objetos, podemos adicionar propriedades e metodos em tempo de execução

ventilador1.cor = "branco";
console.log(ventilador1.cor);

ventilador1.ligaDesliga= function(){
    if(this.ligado)
    this.ligado= false;

    else
     this.ligado=true;
}

ventilador1.ligaDesliga()
console.log(ventilador1.ligado)
ventilador1.ligaDesliga()
console.log(ventilador1.ligado)

console.log(ventilador1);


//Adicionando o métdo por meio do prototipo para que seja aplicado a todos os objetos

function liga(){
    this.ligado=true;
}

ventilador.prototype.ligar=liga;



