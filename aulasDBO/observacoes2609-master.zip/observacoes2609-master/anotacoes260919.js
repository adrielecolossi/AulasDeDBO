/*

O construtor Object cria um wrapper de objeto para o valor fornecido. Se o valor for null ou undefined, ele criará e retornará um objeto vazio, caso contrário, retornará um objeto de um Type que corresponde ao dado valor. Se o valor já for um objeto, ele retornará o valor.

Quando chamado em um contexto não-construtor, o object se comporta de forma idêntica ao new Object ().

*/


/*

OBJETOS

*/

var person = {
    firstName: "John",
    lastName: "Doe",
    age: 50,
    eyeColor: "blue",
    fullName: function () {
        return this.firstName + " " + this.lastName;
    }
};

console.log(person.lastName); //Doe
console.log(person["lastName"]); //Doe

console.log(person.fullName()) //John Doe

name = person.fullName;


var x = new String();        // Declares x as a String object
var y = new Number();        // Declares y as a Number object
var z = new Boolean();       // Declares z as a Boolean object


var Pessoa = {
    nome: 'vinicius',
    idade: 25,
    falar: function (palavras) {
        console.log(this.nome + ' diz: ' + palavras)
    },
    envelhecer: function (anos) {
        this.idade += anos || 1;
        console.log(this.idade)
    }
}

Pessoa.falar('bobagem'); //vinicius diz: bobagem
Pessoa.envelhecer();
Pessoa.envelhecer(4);

var amanda = {
    nome: 'amanda',
    idade: 25,
    falar: function (palavras) {
        console.log(this.nome + ' diz: ' + palavras)
    },
    envelhecer: function (anos) {
        this.idade += anos || 1;
        console.log(this.idade)
    }
}

amanda.falar('bobagem'); //vinicius diz: bobagem
amanda.envelhecer();
amanda.envelhecer(4);

/*

FUNÇÃO CONSTRUTORA

*/

//Podemos ter, tambem, a FUNÇÃO CONSTRUTORA desses objetos

function People(nome, idade) {
    this.nome = nome;
    this.idade = idade;
    this.falar = function (palavras) {
        console.log(this.nome + ' diz: ' + palavras)
    }
    this.envelhecer = function (anos) {
        this.idade += anos || 1;
        console.log(this.idade)
    }
}

var pessoa1 = new People('Vinicius', 25);
console.log(pessoa1);
console.log(pessoa1.falar('aa')) //Vinicius diz: aa

People.prototype.caminhar = function () {
    console.log('a pessoa caminha');
}

pessoa1.caminhar() // a pessoa caminha

/*

OBJECT CREATE

*/


// Encapsulamento das propriedades e métodos de Animal
var Animal = {
    tipo: "Invertebrados", // Propriedades de valores padrão
    qualTipo: function () {  // Método que ira mostrar o tipo de Animal
        console.log(this.tipo);
    }
}

// Cria um novo tipo de animal chamado animal1
var animal1 = Object.create(Animal);
animal1.qualTipo(); // Saída:Invertebrados

// Cria um novo tipo de animal chamado Peixes
var peixe = Object.create(Animal);
peixe.tipo = "Peixes";
peixe.qualTipo(); // Saída: Peixes

/*  

PROTOTYPE

*/

/*
Todos os objetos em JavaScript herdam de pelo menos um outro objeto. O objeto "pai" é conhecido como o 
protótipo, e as propriedades herdadas podem ser encontradas no objeto prototype do construtor.*/


/*

ENCAPSULAMENTO

*/

function Carro() {
    var Marca = "Sem marca";
    var Modelo = "Sem modelo";
    this.SetMarca = SetMarca;
    this.SetModelo = SetModelo;
    this.ShowMarca = DisplayMarca;
    this.ShowModelo = DisplayModelo;

    function DisplayMarca() {
        alert(Marca);
    }

    function DisplayModelo() {
        alert(Modelo);
    }

    function SetMarca(_marca) {
        Marca = _marca;
    }

    function SetModelo(_modelo) {
        Modelo = _modelo;
    }

}
var carro = new Carro();
carro.SetMarca("Ford");
carro.SetModelo("Ka");
carro.ShowMarca();
carro.ShowModelo(); 


/*

ARRAYS NO OBJETO

*/

carro = {
    Marca: "Ford",
    Modelo: "Ka",
    Caracteristicas: ["Preto", 1.0, "2 portas"],

    exibirDetalhes: function () {
        alert("Marca: " + this.Marca + " - Modelo: " + this.Modelo)
    }
}

carro.exibirDetalhes();
alert(carro.Caracteristicas[0])

var Pessoa = { nome: "Maria", idade: 30, sexo: "F" }

var mapa = {
    cantoSuperiorEsquerdo: { x: 1, y: 1 },
    cantoSuperiorDireito: { x: 10, y: 1 },
    cantoInferiorEsquerdo: { x: 1, y: 10 },
    cantoInferiorDireito: { x: 10, y: 10 }
}

alert(mapa.cantoInferiorDireito.x);   


/*

FUNÇÃO DO VENTILADOR

*/


function Ventilador(velMax) {
    this.velocidadeMaxima = velMax;
    this.ligado = false;
}

/*
var obj = new Object();
var data = new Date();
*/

var ventilador1 = new Ventilador(3);

console.log(ventilador1.velocidadeMaxima); // Retorna 3


//Diferente das linguagens clássicas orientadas a objeto, Javascript permite que propriedades sejam
// adicionadas a qualquer momento durante a execução do código.Por exemplo, vamos adicionar a propriedade 
//cor a nosso ventilador:

ventilador1.cor = "branco";
console.log(ventilador1.cor); // Retorna branco


//Métodos em Javascript são funções invocadas por objetos.Para criar um novo método, basta atribuir uma 
//função a um nome no objeto utilizando também o operador “.” como ocorre com as propriedades.O exemplo 
//abaixo demonstra como definir o método ligar para a classe Ventilador utilizando a função liga através da
// propriedade prototype.

function liga() {
    this.ligado = true;
}
Ventilador.prototype.ligar = liga;

//Caso queira adicionar um método a um objeto em particular, pode fazê-lo da seguinte maneira:
ventilador2 = new Ventilador(2);
ventilador2.ligar = liga;

//Outro uso possível é definir o método na estrutura da classe:

function liga() {
    this.ligado = true;
}
function Ventilador(velMax) {
    this.velocidadeMaxima = velMax;
    this.ligado = false;
    this.ligar = liga;
}

/*

O THIS

*/
//A palavra chave this é substituída pelo objeto que invoca a função, essa é uma das principais vantagens da
// utilização de métodos. Exemplo de uso:

var ventilador = new Ventilador(3);
console.log(ventilador.ligado); // Retorna false
ventilador.ligar();
console.log(ventilador.ligado); // Retorna true

/*

OS LITERAIS

*/
//Os literais de objeto3 possibilitam criar e iniciar objetos de uma maneira diferente. A sintaxe é definida
// por uma lista de pares nome/valor separados por vírgulas entre um par de chaves. Cada par nome/valor é 
//definido pelo nome da propriedade seguido de dois pontos e do valor correspondente.

var Livro = {
    titulo: "Os Três Mosqueteiros",
    autor: "Alexandre Dumas",
    capitulo1: {
        titulo: "Os três presentes do sr. D'Artagnan pai",
        paginas: 11
    },
    capitulo2: {
        titulo: "A antecâmara do sr. Tréville",
        paginas: 8
    }
}

/*
ACESSAR PROPRIEDADES 

*/


// Acessando as propriedades:
console.log(Livro.titulo + " - " + Livro.autor + "\\n\\t" +
    Livro.capitulo1.titulo + " - " +
    Livro.capitulo1.paginas + " páginas\\n\\t" +
    Livro.capitulo2.titulo + " - " +
    Livro.capitulo2.paginas + " páginas");

    /*

    COMPOSIÇÃO

    */

//A composição é um recurso utilizado para definir uma relação do tipo “tem um” (“has a” relationship), ou 
//seja, um objeto que conta com outros objetos para formar sua estrutura. Por exemplo, um objeto do tipo 
//Carro teria em sua estrutura objetos do tipo Roda, Volante, Banco. O exemplo anterior que descreve um 
//livro, também demonstra o uso deste recurso.
function Livro(titulo, autor) {
    this.titulo = titulo;
    this.autor = autor;
}

function Capitulo(titulo, paginas) {
    this.titulo = titulo;
    this.paginas = paginas;
}

var livro = new Livro("Os Três Mosqueteiros", "Alexandre Dumas");
var capitulo1 = new Capitulo("Os três presentes do sr. D'Artagnan pai", 11);
var capitulo2 = new Capitulo("A antecâmara do sr. Tréville", 8);

// Os objetos do tipo Capitulo fazem parte da composição do objeto livro
livro.capitulo1 = capitulo1;
livro.capitulo2 = capitulo2;

// Acessando as propriedades:
console.log(livro.titulo + " - " + livro.autor + "\\n\\t" +
    livro.capitulo1.titulo + " - " +
    livro.capitulo1.paginas + " páginas\\n\\t" +
    livro.capitulo2.titulo + " - " +
    livro.capitulo2.paginas + " páginas");


/*

HERANÇA

*/

//Em Javascript a herança ocorre por meio de objetos protótipos4 e define uma relação do tipo “é um” 
//(“is a” relationship). Cada objeto herda propriedades e métodos de seu objeto protótipo que é referenciado
// pela propriedade prototype. A classe Object é a superclasse de todas as classes definidas em Javascript,
// ou seja, todos os construtores criados herdam propriedades e métodos definidos no construtor Object() 
//como por exemplo o método toString(), que assim como outros pode ser sobrescrito na subclasse. Em alguns 
//casos, é conveniente utilizar este recurso em classes personalizadas, para isso basta definir um 
//construtor como valor para a propriedade prototype da classe em questão. Como exemplo simplório, vamos 
//definir a classe Eletrodomestico com a propriedade ligado e os métodos ligar e desligar comuns a todos 
//os eletrodomésticos e então definir a classe Ventilador com propriedades e métodos peculiares.

function Eletrodomestico() {
    this.ligado = false;
    this.ligar = function () {
        this.ligado = true;
    }
    this.desligar = function () {
        this.ligado = false;
    }
}

function Ventilador(velMax) {
    var maximaPermitida = 5; // Uso de encapsulamento
    var velocidadePadrao = 3; // Variáveis privadas
    if (velMax > 0 && velMax <= maximaPermitida) {
        this.velocidadeMaxima = velMax;
    } else {
        this.velocidadeMaxima = velocidadePadrao;
    }
}

Ventilador.prototype = new Eletrodomestico(); // Define o objeto protótipo
ventilador = new Ventilador(4);
console.log(ventilador.ligado); // Retorna false
ventilador.ligar();
console.log(ventilador.ligado); // Retorna true