/*
A mesma deve permitir que o profissional encontre seus pacientes com todos os seus dados pessoais e seja possivel agendar a data de cada consulta de seus pacientes , mas também todos os procedimetos que foram feitos com cada paciente.

Esta pacientes deverá permitir cadastrar, localizar e adicionar consulta. Deverá aparecer sempre o horário agendado e o horario que foi feito e cadastrado cada procedimento e também o serviço realizado. Estes critérios são os básicos que necesssitam ter na pacientes. Vc poderá acrescentar ou trocar os demais para deixar sua pacientes mais atrativa e funcional.

Emita também um relatório simples descrevendo quais foram os relacionamentos, se teve herença, descrever onde, se surgiu polimorfismo também relatar, se precisou gerar um  encapsuamento e todos os demais que vimos na aula passada.
*/

var pacientes=[]; //é um vetor
var consultas=[]
class Paciente{
  constructor(nome, rg, endereco, telefone, nascimento, profissao){
    this._nome= nome;
    this._rg=rg;
    this._endereco= endereco;
    this._telefone= telefone;
    this._nascimento= nascimento;
    this._profissao= profissao;
  }

  verificarPacienteCadastrado(){
    if(this._nome!==undefined&& this._rg!==undefined&& this._endereco!== undefined&& this._telefone!==undefined&& this._nascimento!==undefined&& this._profissao!==''){
      alert('Paciente verificado!')
    } else{
      alert('O paciente foi verificado mas há ausência de alguma(s) informação/informações faltando.')
    }
  }
  AdicionarPaciente(){
    if (pacientes[0]===undefined){
        pacientes[0]= 'Nome:' + this._nome + '\nRg:' + this._rg + '\nEndereco:' + this._endereco + '\nTelefone:' + this._telefone + '\nNascimento' + this._nascimento + '\nProfissao: ' + this._profissao
  } else{
      pacientes[pacientes.length] = 'Nome:' + this._nome + '\nRg:' + this._rg + '\nEndereco:' + this._endereco + '\nTelefone:' + this._telefone + '\nNascimento' + this._nascimento + '\nProfissao: ' + this._profissao
  }
alert('A lista de pacientes agora é ' + pacientes);
}
  ObterPaciente(){
    var numb= parseInt(prompt("Informe o número do paciente (ex 1, 2, 3...)"))
    alert(pacientes[numb-1]) 
  }
  ObterConsulta(){
    var numb2= parseInt(prompt("Informe a data da consulta (ex 1, 2, 3...)"));
    alert(consultas[numb2-1]);

  }
  AdicionarConsulta(){
    var data= parseInt(prompt("Informe a data da consulta"))
    consultas[consultas.length]= data;
  }
  LocalizarPaciente(){ //mesma função de obter paciente
    var numb3 = parseInt(prompt("Informe o número do paciente (ex 1, 2, 3...)"))
    alert(pacientes[numb - 1]) 
  }
    CadastrarPaciente(){ //mesma função de adicionar pacientes
      if (pacientes[0] === undefined) {
        pacientes[0] = 'Nome:' + this._nome + '\nRg:' + this._rg + '\nEndereco:' + this._endereco + '\nTelefone:' + this._telefone + '\nNascimento' + this._nascimento + '\nProfissao: ' + this._profissao + '\n'
      } else {
        pacientes[pacientes.length] = 'Nome:' + this._nome + '\nRg:' + this._rg + '\nEndereco:' + this._endereco + '\nTelefone:' + this._telefone + '\nNascimento' + this._nascimento + '\nProfissao: ' + this._profissao + '\n'
      }
      alert('A lista de pacientes agora é \n' + pacientes + '\n\n');
    }
}

class Agenda{
  constructor(ano){
    this._ano= ano;
  }
  AbrirAgenda(){    //não tenho certeza do que fazer nas funções
    alert('AGENDA ' + this._ano + '\n\nPacientes: ' + pacientes +'\n\nDias das consultas: ' + consultas);
  }
  ResgatarAgendaDia(){
    var diadehoje=prompt("Informe o dia");
    //consultas.charAt(dia)
    alert('Paciente(s): ' + pacientes[consultas.indexOf(diadehoje)])
  }
  ResgatarAgenda2Dias(){
    var doisdias= prompt("Informe o dia de hoje");
    var alertar='';
    if (pacientes[consultas.indexOf(doisdias-1)]!=undefined){
      alertar += pacientes[consultas.indexOf(doisdias - 1)];
    } else{
      alertar+= 'Não há pacientes do dia ' + (doisdias-1)
    }
    if (pacientes[consultas.indexOf(doisdias - 2)] != undefined) {
      alertar += pacientes[consultas.indexOf(doisdias - 2)];
    } else {
      alertar += 'Não há pacientes do dia ' + (doisdias - 2);
    }
   alert(alertar)
  }
  ResgatarAgendaSemana(){
    var semana= prompt("Informe o dia de hoje");
    var alertar2='';
    if (pacientes[consultas.indexOf(semana - 1)] != undefined) {
      alertar2 += pacientes[consultas.indexOf(semana - 1)];
    } else {
      alertar2 += 'Não há pacientes do dia ' + (semana - 1)
    }

    if (pacientes[consultas.indexOf(semana - 2)] != undefined) {
      alertar2 += pacientes[consultas.indexOf(semana - 2)] + '\n';
    } else {
      alertar2 += 'Não há pacientes do dia ' + (semana - 2) + '\n'
    }
    if (pacientes[consultas.indexOf(semana - 3)] != undefined) {
      alertar2 += pacientes[consultas.indexOf(semana - 3)] + '\n';
    } else {
      alertar2 += 'Não há pacientes do dia ' + (semana - 3) + '\n'
    }
    if (pacientes[consultas.indexOf(semana - 4)] != undefined) {
      alertar2 += pacientes[consultas.indexOf(semana - 4)] + '\n';
    } else {
      alertar2 += 'Não há pacientes do dia ' + (semana - 4) + '\n'
    }
    if (pacientes[consultas.indexOf(semana - 5)] != undefined) {
      alertar2 += pacientes[consultas.indexOf(semana - 5)] + '\n';
    } else {
      alertar2 += 'Não há pacientes do dia ' + (semana - 5) + '\n'
    }
    if (pacientes[consultas.indexOf(semana - 6)] != undefined) {
      alertar2 += pacientes[consultas.indexOf(semana - 6)] + '\n';
    } else {
      alertar2 += 'Não há pacientes do dia ' + (semana - 6) + '\n'
    }
    if (pacientes[consultas.indexOf(semana - 7)] != undefined) {
      alertar2 += pacientes[consultas.indexOf(semana - 7)] + '\n';
    } else {
      alertar2 += 'Não há pacientes do dia ' + (semana - 7) + '\n'
    }
  alert(alertar2);
  }
}

class Horario extends Agenda{
  constructor(data, hora){
    super(ano);
    this._data=data;
    this._hora= hora;
  }
  obterHorariosDisponiveis(){ //dias disponiveis
  var diasdisponiveis=[];
  for(let c=0; c<31; c++){
    if(consultas.indexOf(c)==-1){
      diasdisponiveis[diasdisponiveis.length]=c;
    }
  }
  }
  AlterarDisponibilidadeHorario(){
    var alterar= parseInt(prompt("Informe o dia que vocẽ deseja alterar a disponibilidade"));
    for(let c2=0;c2<consultas.length; c2++){
      if(consultas[c2]==alterar){
        consultas[c2]= undefined;
      }
    } 
  }
}

class Consulta{
  constructor(historico){
    this._historico=historico;
  }
  RegistrarConsulta(){
    var data2 = parseInt(prompt("Informe a data da consulta"))
    consultas[consultas.length] = data2;
  }
  RecuperarHistoricoConsulta(){
    //criar um while que veja quais as datas que a pessoa ja fez consulta
    var consultastotais='';
    for(let c3=0; c3<consultas.length; c3++){
      consultastotais+= '\nData: '+ consultas[c3] + '\n' + pacientes[c3];
    }
  alert(consultastotais);
  }
}

class Servico{
  constructor(descricao, preco){
    this._descricao=descricao;
    this._preco=preco;
  }
  RegistrarServico(){ //não podemos registrar exatamente, não há banco de dados
    alert("O serviço foi registrado")}
  RecuperarServico(){
    alert("O serviço foi recuperado")
  }
}

class LimpezaRestauracao extends Servico{
  constructor(descricao, preco, materialusado, dentetratado){
    super(descricao, preco)
    this._materialusado= materialusado;
    this._dentetratado= dentetratado;
  }
}

class Exame extends Servico{
  constructor(descricao, preco, medidapreventiva, tipodeexame) {
    super(descricao, preco)
   this._medidapreventiva= medidapreventiva;
   this._tipodeexame= tipodeexame;
}
}
