class Controlador{
   constructor(volume, ligado, tocando){
     this._volume= volume;
     this._ligado= ligado;
     this._tocando= tocando;
   }
Construtor(){
  this._volume= 50;
  this._ligado= false;
  this._tocando= false;
}
}

class ControleRemoto extends Controlador{
  constructor(volume, ligado, tocando) {
    super(volume, ligado, tocando);
    this._volume = volume;
    this._ligado = false;
    this._tocando = false;
  }
  ligar(){
    this._ligado=true;
  }
  desligar(){
    this._ligado= false;
  }
  abrirMenu(){
    alert("Volume: " + this._volume + "\nLigado: " + this._ligado  +"\nTocando " + this._tocando);
  }
  fecharMenu(){
    alert("Você fechou o menu")
  }
  maisVolume(){
    this._volume= parseInt(this._volume) + 1;
  }
  menosVolume(){
    this._volume= parseInt(this._volume) -1
  }
  ligarMudo(){
    this._volume=0;
  }
  desligarMudo(){
    this.volume= volume;
  }
  play(){
    alert("Você despausou");
  }
  pause(){
    alert("Você pausou");
  }

}