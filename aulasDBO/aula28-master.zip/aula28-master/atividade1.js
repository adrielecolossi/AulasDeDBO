class Pessoa{
  //atributos
  constructor(nome, idade,sexo) {
    this.nome = nome;
    this.idade = idade;
    this.sexo = sexo;
  }
  //metodos

  fazerAniv(){
    this.idade= parseInt(this.idade)+1
    alert("A idade agora é " + (parseInt(this.idade)+1));
  }
}


class Aluno extends Pessoa{

//atributos
  constructor(nome,idade,sexo, matr, curso){
    super(nome,idade,sexo);
    this.matr= matr;
    this.curso= curso;
  }

//metodos 

cancelarMatr(){
  alert("A matrícula foi cancelada");
  delete(this.matr);
}

}

class Funcionario extends Pessoa{

//atributos

  constructor(nome, idade, sexo, setor, trabalhando) {
    super(nome, idade, sexo);
    this.setor = setor;
    this.trabalhando = trabalhando;
  }

//metodo 

  mudarTrabalho(novotrabalho){
   this.trabalho= novotrabalho;
  }

//metodos especiais 

}

class Professor extends Pessoa{

  //atributos

  constructor(nome, idade, sexo, especialidade, salario) {
    super(nome, idade, sexo);
    this.especialidade = especialidade;
    this.salario = salario;
  }

//metodo

ReceberAUm(i){
this.salario=(parseInt(salario)+i)
}

}

p1= new Pessoa("Pedro", 15, 'masculino');
p2= new Aluno("Maria", 15, 'feminino', "11030324", 'informática')
p3= new Professor("Claudio", 18, 'masculino', 'administração', 2500.75 )
p4= new Funcionario("Fabiana", 18, 'feminino', 'estoque', true)