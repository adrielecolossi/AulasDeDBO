class Animal{
  constructor(peso, idade, membros){
    this._peso= peso; //peso encapsulado, usando o _
    this._idade= idade;
    this._membros= membros;
  }
}


class Mamifero extends Animal{
  constructor(peso, idade, membros, corPelo){
    super(peso, idade, membros)
    this._corPelo= corPelo
  }

  locomover() {
    console.log("Correndo");
  }

  alimentar() {
    console.log("Mamando");
  }
  emitirSom() {
    console.log("Som de mamífero");
  }
}

class Reptil extends Animal{
  constructor(peso, idade, membros, corEscama){
    super(peso, idade, membros)
    this._corEscama= corEscama;
  }

  locomover() {
    console.log("Rastejando");
  }

  alimentar() {
    console.log("Comendo vegetais");
  }
  emitirSom() {
    console.log("Som de reptil");
  }
}

class Peixes extends Animal{
  constructor(peso, idade, membros, corEscama){
    super(peso, idade, membros)
    this._corEscama= corEscama;
  }

  locomover() {
    console.log("Nadando");
  }

  alimentar() {
    console.log("Comendo substancias");
  }
  emitirSom() {
    console.log("Peixe não faz som");
  }
  soltarBolha(){
    console.log("Soltou um bolha")
  }
}

class Ave extends Animal{
  constructor(peso, idade, membros, corPena){
    super(peso, idade, membros)
    this._corPena= corPena;
  }

  locomover() {
    console.log("Voando");
  }

  alimentar() {
    console.log("Comendo frutas");
  }
  emitirSom() {
    console.log("Som de ave");
  }
  fazerNinho(){
    console.log("Construiu um ninho")
  }
}


m= new Mamifero()
r= new Reptil()
p= new Peixes()
a= new Ave()

m.locomover();
r.alimentar();
p. soltarBolha();
a.fazerNinho();


class Canguru extends Mamifero{
  constructor(peso, idade, membros, corPelo) {
    super(peso, idade, membros, corPelo)
  }

usarBolsa(){
  console.log("Usando bolsa")
}
locomover(){
  console.log("Saltando")
}
}

class Cachorro extends Mamifero{
  constructor(peso, idade, membros, corPelo) {
    super(peso, idade, membros, corPelo)
  }

enterrarOsso(){
  console.log("Enterrando Osso")
}
abanarRabo(){
  console.log("Abanando o Rabo")
}
}

class Cobra extends Reptil{
  constructor(peso, idade, membros, corPelo) {
    super(peso, idade, membros, corPelo)
  }

}


class Tartaruga extends Reptil {
  constructor(peso, idade, membros, corPelo) {
    super(peso, idade, membros, corPelo)
  }

  locomover(){
    console.log("Andando beeeeem devagar");
  }
}

class Goldfish extends Peixes{
  constructor(peso, idade, membros, corEscama) {
    super(peso, idade, membros, corEscama)
  }

}

class Arara extends Ave{
  constructor(peso, idade, membros, corPena) {
    super(peso, idade, membros, corPena)
  }
}
