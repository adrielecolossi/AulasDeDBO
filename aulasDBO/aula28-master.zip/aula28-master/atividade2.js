class Lutador{
constructor(nome, nacionalidade, idade, altura, peso, categoria, vitorias, derrotas, empates){
this.nome= nome;
this.nacionalidade= nacionalidade;
this.idade= idade;
this.altura= altura;
this.peso= peso;
this.categoria= categoria;
this.vitorias= vitorias;
this.derrotas= derrotas;
this.empates= empates;
}

apresentar(){
  alert("Lutador " + this.nome + "!\nNacionalidade: " + this.nacionalidade + "\nIdade: " + this.idade + "\nAltura:" + this.altura + "\nPeso: "+ this.peso);
}

Status(){
  alert("Vitorias: " + this.vitorias + "\nDerrotas: " + this.derrotas + "\nEmpates" + this.empates);
}

ganharLuta(){
  this.vitorias= parseInt(this.vitorias) + 1;
  }

perderLuta() {
    this.derrotas = parseInt(this.derrotas) + 1;
  }

empatarLuta() {
    this.empates = parseInt(this.empates) + 1;
  }

}

var L= [0,1,2,3];

L[0]= new Lutador("Pretty Boy", "França", 31, 1, 68, 11, 3, 1);
L[1] = new Lutador("Putscript", "Brasil", 29, 1, 57, 14, 2, 3 );
L[2]= new Lutador("SnapShadow", "EUA", 35, 1.65, 80.9, 12, 2, 1);
L[3] = new Lutador("Dead Code", "Australia", 28, 1.93, 81.6, 13, 0, 2)